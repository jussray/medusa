'use strict';
/* Medusa preview: zero network requests, persistence, or automatic actions. */
const MAX_IMPORT_BYTES = 4 * 1024 * 1024;
const NAV_IDS = ['overview', 'findings', 'evidence', 'defense', 'integrity'];
let assessment = null;
let currentView = 'overview';
let importedHash = '';

const $ = (id) => document.getElementById(id);
const text = (id, value) => { $(id).textContent = redact(value); };
function redact(value) {
  const s = String(value ?? '');
  return s
    .replace(/-----BEGIN [A-Z\d ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z\d ]*PRIVATE KEY-----/gi, '[REDACTED:private_key]')
    .replace(/\b(?:gh[pousr]_[A-Za-z0-9]{20,}|sk_live_[A-Za-z0-9]{12,}|AKIA[0-9A-Z]{16})\b/g, '[REDACTED:credential]')
    .replace(/\b(?:Bearer\s+)[A-Za-z0-9._~+\/-]{12,}=*/gi, '[REDACTED:bearer]')
    .replace(/\b(?:api[_-]?key|secret|token|password|passwd|pwd)\s*[:=]\s*['"]?[^\s'"]{5,}['"]?/gi, '[REDACTED:assignment]')
    .replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, '[REDACTED:email]')
    .slice(0, 500);
}
function node(tag, value, cls) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  n.textContent = redact(value);
  return n;
}
function go(view) {
  currentView = view;
  for (const id of NAV_IDS) {
    $('view-' + id).hidden = id !== view;
  }
  for (const btn of document.querySelectorAll('[data-view]')) {
    const active = btn.dataset.view === view;
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-current', active ? 'page' : 'false');
  }
  text('breadcrumb-section', view.toUpperCase());
}
function listFindings() { return Array.isArray(assessment?.findings) ? assessment.findings : []; }
function severityCount(values) { return listFindings().filter(f => values.includes(f?.severity)).length; }
function renderFindings() {
  const tbody = $('findings-table');
  tbody.replaceChildren();
  const filter = $('severity-filter').value;
  const list = listFindings().filter(f => filter === 'All' || f.severity === filter);
  if (!list.length) {
    const tr = document.createElement('tr');
    const td = node('td', assessment ? 'No matching findings' : 'Load an assessment to see findings', 'empty-cell');
    td.colSpan = 6;
    tr.append(td); tbody.append(tr); return;
  }
  for (const f of list.slice(0, 3000)) {
    const tr = document.createElement('tr');
    tr.append(node('td', f?.id || '—'));
    const sevTD = document.createElement('td');
    const severity = ['Critical','High','Medium','Low'].includes(f?.severity) ? f.severity : 'Unknown';
    const sev = node('span', severity, 'severity severity-' + severity.toLowerCase());
    sevTD.append(sev); tr.append(sevTD);
    tr.append(node('td', f?.source || '—'));
    tr.append(node('td', f?.attack || '(empty)'));
    tr.append(node('td', f?.evidence_tag || 'UNVERIFIED'));
    tr.append(node('td', f?.rebuttal_outcome || 'Not reviewed'));
    tbody.append(tr);
  }
}
function renderEvidence() {
  const target = $('evidence-details'); target.replaceChildren();
  if (!assessment) { target.append(node('div', 'No assessment loaded.')); return; }
  const grouped = {VERIFIED:0, INFERRED:0, UNVERIFIED:0, Other:0};
  const prov = {};
  for (const f of listFindings()) {
    if (Object.hasOwn(grouped, f.evidence_tag)) grouped[f.evidence_tag]++;
    else grouped.Other++;
    const p = String(f?.provenance || 'not recorded'); prov[p] = (prov[p] || 0) + 1;
  }
  const cards = [
    ['Evidence classifications', Object.entries(grouped).map(([k,v]) => k + ': ' + v).join(' · ')],
    ['Reported provenance', Object.entries(prov).map(([k,v]) => k + ': ' + v).join(' · ') || 'No source recorded'],
    ['Stone test', assessment.stone?.assumption || 'Not recorded'],
    ['Stone evidence identity', assessment.stone?.evidence?.sha256 ? 'Hash present in record. Not independently verified.' : 'No referenced evidence hash'],
    ['Verification limitation', 'Claims, source quotes, file hashes, signed seals, and scope have not been independently verified.']
  ];
  for (const [label, val] of cards) {
    const div = document.createElement('div'); div.className = 'detail-card';
    div.append(node('strong', label), node('span', val)); target.append(div);
  }
}
function renderDefense() {
  const target = $('defense-details'); target.replaceChildren();
  if (!assessment) { target.append(node('div', 'No assessment loaded.')); return; }
  const defenses = assessment.defense && typeof assessment.defense === 'object' ? assessment.defense : {};
  const found = Object.entries(defenses);
  if (!found.length) { target.append(node('div', 'No control records present. This is not evidence of safety.', 'detail-card')); return; }
  for (const [fid, controls] of found.slice(0, 200)) {
    if (!Array.isArray(controls)) continue;
    for (const ctrl of controls.slice(0, 50)) {
      const div = document.createElement('div'); div.className = 'detail-card';
      div.append(node('strong', fid + ' · ' + (ctrl?.type || 'control')),
        node('span', (ctrl?.statement || 'No statement') + ' — Verification plan: ' + (ctrl?.verify || 'not recorded')));
      target.append(div);
    }
  }
}
function render() {
  text('record-state', assessment ? 'LOCAL RECORD · NOT VERIFIED' : 'NO RECORD LOADED');
  text('assessment-name', assessment?.name || 'Not loaded');
  text('finding-count', assessment ? listFindings().length : '—');
  text('major-count', assessment ? severityCount(['Critical','High']) : '—');
  text('stakes-label', assessment?.stakes || 'Not set');
  text('nav-findings', listFindings().length);
  const provCount = new Set(listFindings().map(f => f?.provenance).filter(Boolean)).size;
  text('provenance-readout', assessment ? provCount + ' provenance category/categories recorded; unverified' : 'No assessment loaded');
  text('evidence-readout', assessment ? listFindings().filter(f=>f?.evidence_tag==='VERIFIED').length + ' findings labeled VERIFIED by source; not independently checked' : 'No independent check performed');
  const defenses = assessment?.defense;
  const ctrlCount = defenses && typeof defenses==='object' ? Object.values(defenses).filter(Array.isArray).reduce((n,a)=>n+a.length,0) : 0;
  text('defense-readout', assessment ? ctrlCount + ' controls reported; effectiveness not tested' : 'No independently verified controls');
  text('record-hash', importedHash || 'Not computed');
  text('record-decider', assessment?.decider || 'Not set');
  text('record-stone', assessment?.stone?.assumption || 'Not set');
  renderFindings(); renderEvidence(); renderDefense();
}
function validate(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Assessment must be a JSON object.');
  if (typeof input.name !== 'string' || input.name.length > 120) throw new Error('Missing/invalid assessment name.');
  if (!Array.isArray(input.findings) || input.findings.length > 3000) throw new Error('Missing or excessive findings array.');
  if (input.findings.some(f=> !f || typeof f!=='object' || Array.isArray(f))) throw new Error('Invalid finding entry.');
  return input;
}
async function sha256(bytes) {
  if (!globalThis.crypto?.subtle) return 'Unavailable in this browser context';
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash), x => x.toString(16).padStart(2, '0')).join('');
}
async function importBytes(bytes, label) {
  if (bytes.byteLength > MAX_IMPORT_BYTES) throw new Error('JSON exceeds 4 MiB limit.');
  const decoded = new TextDecoder('utf-8', {fatal:true}).decode(bytes);
  const parsed = validate(JSON.parse(decoded));
  assessment = parsed;
  importedHash = await sha256(bytes);
  render(); go('overview');
  text('notice', 'Imported "' + redact(label) + '" into browser memory only. Content remains unverified; no upload or security gate was executed.');
}
function loadDemo() {
  const sample = {
    name:'payouts-v2-demo', target:'Payout retry review (synthetic example)', stakes:'consequential',
    decider:'payments lead', material:['design doc v3 — synthetic'], audience:['payments lead'],
    stone:{assumption:'idempotency key is unique per payout intent',verified:false,reversal:'independent replay test + uniqueness constraint'},
    findings:[
      {id:'F1',source:'pass1',severity:'Critical',attack:'Duplicate payout on retry',evidence_tag:'INFERRED',provenance:'authored',rebuttal_outcome:'stands'},
      {id:'A1',source:'adversary',severity:'High',attack:'Insider changes payout target without review',evidence_tag:'UNVERIFIED',provenance:'authored',rebuttal_outcome:null},
      {id:'F2',source:'pass1',severity:'Medium',attack:'Loss of traceability across retries',evidence_tag:'INFERRED',provenance:'authored',rebuttal_outcome:null}
    ],
    defense:{F1:[{type:'preventive',statement:'Unique constraint proposed',verify:'A replay test would be required'}]}
  };
  assessment = sample; importedHash = 'Synthetic sample — not a file hash';
  render(); go('overview');
  text('notice','Synthetic demonstration loaded. No system was tested, no gates ran, and no approval is granted.');
}
function clear() { assessment=null; importedHash=''; $('file-input').value=''; render(); go('overview'); text('notice','Session cleared. No assessment data was stored on a server or in browser storage.'); }
for(const b of document.querySelectorAll('[data-view]')) b.addEventListener('click',()=>go(b.dataset.view));
$('import-button').addEventListener('click', ()=>$('file-input').click());
$('demo-button').addEventListener('click', loadDemo);
$('clear-button').addEventListener('click',clear);
$('severity-filter').addEventListener('change',renderFindings);
$('file-input').addEventListener('change',async e=>{
  const f=e.target.files?.[0]; if(!f)return;
  try {if(f.size>MAX_IMPORT_BYTES)throw new Error('Assessment exceeds 4 MiB.'); await importBytes(await f.arrayBuffer(),f.name);}
  catch(err) {text('notice','Import refused: '+redact(err.message||'Unknown error'));}
});
render();
