# Medusa — browser-only online staging preview

## Scope

This is a functional, responsive **review UI**, not the Python A–D cybersecurity engine and not an authorization gate. It has no backend, no `fetch()` calls, no account access, no persistence, and no deployment controls. Use only synthetic records in public previews. Imported JSON stays within the current browser tab.

## Hosting

The `site/` directory can be hosted as static assets by Cloudflare Pages (or an equivalent static host). The `_headers` file supplies a strict CSP. `frame-ancestors` and other response headers require hosting that honors `_headers`.

For **private production service** rather than a demo: require authenticated sign-in (e.g., Cloudflare Access), isolate each decider's assessments, keep the Python A–D engine in a non-egress-capable backend, put keys/anchors outside the assessment trust boundary, and keep the separately authorized acquisition worker isolated. Do not enable upload/persistence or decision/CI actions until A–D acceptance tests and custody tests pass.

## Local preview

From `site/` run `python3 -m http.server 8000`, then open http://localhost:8000. This is a local development server, not production hosting.

## Current behavior

- View five-pass methodology.
- Open a synthetic demonstration or manually import a Medusa JSON assessment (maximum 4 MiB).
- Navigate findings/evidence/defenses/integrity and filter findings by severity.
- Render imported fields as text, with best-effort masking of common secret/PII formats.
- Display local source hash if browser WebCrypto is available.
- **Never** assert that source claims, signatures, scan results, or verdicts are verified.

## Known limitations

Best-effort regex masking is not complete secret detection. Do not import private production assessments into a public site without an independently verified privacy posture. The core Python reconciliation (stone quote, provenance, redaction, fetcher manifest safety, concurrency tests) is **not included** or claimed tested here. Static hosting makes the dashboard reachable online; it does not turn the reference Python modules into a verified online service.

## Deployment authority

No merge, production deployment, external fetch, file sharing, or CI gate has been authorized by this preview. Hold remains active.
