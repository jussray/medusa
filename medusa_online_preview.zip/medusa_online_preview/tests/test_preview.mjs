import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..', 'site');
const src = fs.readFileSync(path.join(root, 'app.js'),'utf8');
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
const headers = fs.readFileSync(path.join(root,'_headers'),'utf8');

function bootstrap(){
  const listeners = new Map();
  const ids = new Map();
  function el(id='') {return {id,hidden:false,textContent:'',className:'',dataset:{},value:'All',children:[],classList:{toggle(){}},setAttribute(){},addEventListener(event,fn){listeners.set(id+':'+event,fn)},append(...nodes){this.children.push(...nodes)},replaceChildren(){this.children=[]}}}
  const document = {
    getElementById(id){ if(!ids.has(id))ids.set(id,el(id));return ids.get(id)},
    querySelectorAll(){return []},
    createElement(tag){return el(tag)}
  };
  const ctx=vm.createContext({document,TextDecoder,Uint8Array,crypto:globalThis.crypto});
  vm.runInContext(src,ctx);
  return {ctx,ids,listeners};
}
test('script and CSP prevent browser network APIs',()=>{
  assert.doesNotMatch(src,/\bfetch\s*\(|\bXMLHttpRequest\s*\(|\bWebSocket\s*\(|\blocalStorage\b\s*\./);
  assert.match(headers,/connect-src 'none'/);
  assert.match(headers,/frame-ancestors 'none'/);
});
test('all five sections and preview authority warning are present',()=>{
  for(const id of ['overview','findings','evidence','defense','integrity'])assert.match(html,new RegExp('view-'+id));
  assert.match(html,/not a deployment gate/i);
});
test('uploaded HTML is rendered only as text',()=>{
  const {ctx}=bootstrap();
  const out=vm.runInContext('node("div", "<script>alert(1)</script>")',ctx);
  assert.equal(out.textContent,'<script>alert(1)</script>');
  assert.equal(out.children.length,0);
});
test('import rejects invalid finding shapes',()=>{
  const {ctx}=bootstrap();
  assert.throws(()=>vm.runInContext('validate({name:"x",findings:[null]})',ctx),/Invalid finding/);
  assert.throws(()=>vm.runInContext('validate({name:"x"})',ctx),/findings/);
});
test('common credentials and emails masked',()=>{
  const {ctx}=bootstrap();
  const masked=vm.runInContext('redact("password=secret123 test@example.com sk_live_abcdefghijklmnopqrstuvwxyz")',ctx);
  assert.doesNotMatch(masked,/secret123|test@example|sk_live_/);
});
