# Medusa implementation verification checklist

For every claim, capture exact source commit/file hash, test name, command, exit code, and output. A passing synthetic test is not proof of a production workflow.

- [ ] Part A: preflight, completed passes, source-backed stone, rebuttal/cut rules, precedence, change IDs.
- [ ] Part B: secret/PII scan, complete redaction and post-redaction scan, custody, defense evidence freshness.
- [ ] Part C: sequence/HMAC or signature chain continuity; independently anchored signed seal; strict drift exit nonzero; concurrent writer exclusion; SARIF redaction/source locations; watch content hashing and trustworthy alerts.
- [ ] Part D: all gates mandatory for actionable ALLOW, `--only` exits diagnostic code, signed/authorized Proceed, trusted signer identity, current reference hashes, no mutation of Part A by verification commands, no stale sidecars.
- [ ] Acquisition: separate fetcher with no automatic redirect, no DNS TOCTOU, no symlink/traversal/overwrite, private destination blocked, no secret-bearing URL disclosure, verified paired manifest, human admission.
- [ ] Deploy: separately authorized release, exact approved SHA/digest rechecked by the deployment action, receipt linking actor, timestamp, commit and observed result. No automatic merge/deploy solely because Medusa gate passes.

Status taxonomy: AUTHOR/OBSERVED/USER-REPORTED/VERIFIED. Don't call code patched, installed, tested, signed or deployed without evidence from that action.
