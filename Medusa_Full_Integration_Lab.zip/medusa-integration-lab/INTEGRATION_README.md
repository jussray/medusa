# Medusa — Layer 6 synthetic integration candidate

**Status: LAB-ONLY. NOT CANONICAL. NOT INSTALLED. NOT DEPLOYED.**

This package removes the previous **local missing-module runtime blocker** by supplying
newly authored, offline LAB implementations of the five interfaces that the Layer 6
supervisor expects:

- `eventbus.py`: signed, locked, append-only JSONL bus + independently verified anchor in a separate lab directory.
- `detect.py`: declarative YAML rule evaluation, detection events only (no action policy).
- `authority_grant.py`: Ed25519 signed and revocable scoped grants.
- `actuator.py`: bounded, reversible lab file quarantine and undo.
- `fs_sensor.py`: offline polling filesystem sensor (no watchdog dependency).

`medusa_daemon.py` is based on the previous **local, reconstructed** Layer 6 candidate.
It now uses durable intent-before-effect claims (`action_intents/*.json`), prevents
automatic reexecution of a claimed action, and escalates interrupted `pending`
intents on startup. The filesystem claim and completion operations are fsynced.

## Reproduce on a supported Linux local system

Prerequisites: Python 3, OpenSSL, `cryptography`, `PyYAML`, `pytest`.

```sh
python3 -m pip install -r requirements-lab.txt
make test
make lab-acceptance
make bus-stress
```

The acceptance script creates temporary synthetic files, generates test-only
Ed25519 keys, sets `MEDUSA_LAB_MODE=1`, starts a polling sensor, and runs a
complete signed sensor → bus → detection → policy/grant → quarantine/undo →
revocation/escalation → checkpoint-truncation check. The sensor uses a lab-only
temporary watch directory. The test destroys nothing outside its synthetic
workspace; its artifacts are intentionally kept for inspection, not included
in this archive. **Do not run as root or point the fixture at real data.**

## Observed in this build

- `python3 -m pytest -q tests/test_layer6_contract.py tests/test_action_idempotency.py tests/test_eventbus_trust.py`: **17 passed**.
- `bash acceptance.sh`: **18 PASS, 0 FAIL, exit 0** after latest bus trust correction.
- `python3 tests/stress_bus.py --writers 25 --events 10`: **250/250, exit 0**, HMAC-free Ed25519 signed chain, 5.03 s.
- Python compilation + shell syntax: passed.

These results are from the provided synthetic lab copies, **not** from the claimed
`feat/medusa-offline-security-v1-1` branch or the user’s authoritative Layers 1–5.
There has been no GitHub source hash comparison and no installation/merge/deploy.

## Important unclosed gates

1. **Source identity:** the official Layer 1–5 modules were not retrievable from a confirmed repository. All five supplied interfaces here are newly authored lab implementations, **not** replacements for canonical production code. Reconcile their schemas and security controls with the actual branch before integration there.
2. **Key custody and trust:** trusted signers, sensors, checkpoints, and test key files all reside in one synthetic temporary workspace, not distinct production custody boundaries. The lab-only registration CLI is not production trust provisioning.
3. **Actuator journaling:** the lab actuator's rename and undo-token write are not crash-atomic. A crash between them requires operator recovery. Its core is intentionally non-production.
4. **Stresses:** 25 x 10 bus events passed; sustained 25 x 100 bus events was **not run** in this build. The bus verifies its full chain on each append, yielding quadratic total cost under sustained load.
5. **Release:** A–D, hardware-held decider key, independent witness, real source identity, and deploy-side require-digest remain separate gates. This package grants no production authority.
6. **Online deployment:** none was performed; Medusa's previously authored web preview is separate from this offline supervisor.

## Safety boundary

The event bus rejects implicit self-registration even if a caller passes
`allow_self_registration=True`; explicit identity registration is required.
The daemon uses a singleton lock, refuses duplicate action claims, and treats
unknown outcome/failed dispatch as an escalation. It **does not** gain
permission from mere detection events, and there is **no automatic deploy**.
