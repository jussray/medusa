#!/usr/bin/env python3
"""LAB-ONLY restricted reversible quarantine, not an operational security actuator."""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, uuid
import eventbus
import authority_grant as GRANT

EVIDENCE_ORDER={'UNVERIFIED':0,'INFERRED':1,'VERIFIED':2}
SEVERITY_ORDER={'Low':1,'Medium':2,'High':3,'Critical':4}

def lab_only():eventbus.lab_only()
def base_dir(name):return os.environ[name]
def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(8192),b''):h.update(chunk)
    return h.hexdigest()
def _inside(path, scope):
    return path==scope or path.startswith(scope+os.sep)
def path_in_scope(target,target_scope,excluded_paths=None):
    """Require inside explicit non-symlink scope and not excluded."""
    if not isinstance(target,str) or not os.path.isabs(target) or not isinstance(target_scope,str):
        return False,'not absolute'
    scope=os.path.realpath(target_scope)
    resolved=os.path.realpath(target)
    if not _inside(resolved,scope):return False,'out_of_scope'
    if os.path.islink(target):return False,'symlink target'
    for ex in excluded_paths or []:
        if _inside(resolved,os.path.realpath(ex)):return False,'excluded'
    return True,'ok'

def _trusted_identity(sensor_id,key_path):
    trusted=eventbus._trust('sensors')
    k=eventbus._priv(key_path)
    if trusted.get(sensor_id)!=eventbus._pub(k):raise ValueError('invalid actuator identity')

def _check_evidence(detection,target):
    if not isinstance(detection,dict) or 'event' not in detection:raise ValueError('invalid detection')
    did=detection['event'].get('event_id')
    bus={r['event']['event_id']:r for r in eventbus.read_events()}
    matched=bus.get(did)
    if not matched or matched['event']['event_type']!='detection_feedback':
        raise ValueError('detection missing from verified bus')
    evidence_ids=matched['payload'].get('evidence_ref',[])
    if not any(bus.get(eid,{}).get('payload',{}).get('path')==target for eid in evidence_ids):
        raise ValueError('target not in detection evidence')
    return matched

def _check_grant(g,det,target):
    ok,why=GRANT.verify_grant(g,GRANT.load_trusted())
    if not ok:raise ValueError('refused: grant '+why)
    ok,why=path_in_scope(target,g['target_scope'],g.get('excluded_paths'))
    if not ok:raise ValueError('refused: '+why)
    if EVIDENCE_ORDER[det['payload']['evidence_tag']]<EVIDENCE_ORDER[g['requires_evidence_tag']]:
        raise ValueError('refused: evidence insufficient')
    if SEVERITY_ORDER[det['payload']['severity']]<SEVERITY_ORDER[g['requires_detection_severity']]:
        raise ValueError('refused: severity insufficient')
    if g['action_class']!='quarantine_file':raise ValueError('refused: class not supported')

def _manifest_path(uid):return os.path.join(base_dir('MEDUSA_UNDO_DIR'),uid+'.undo.json')

def do_quarantine(target,grant,detection_event,actuator_id,key_path):
    lab_only();_trusted_identity(actuator_id,key_path)
    target=os.path.abspath(target)
    _check_grant(grant,detection_event,target)
    _check_evidence(detection_event,target)
    if not os.path.isfile(target) or os.path.islink(target):raise ValueError('refused: target is not regular file')
    undo_id=uuid.uuid4().hex
    qdir=os.path.join(base_dir('MEDUSA_QUARANTINE_DIR'),undo_id)
    os.makedirs(qdir,mode=0o700,exist_ok=False)
    qpath=os.path.join(qdir,os.path.basename(target))
    checksum=digest(target)
    os.replace(target,qpath)
    undo={'undo_id':undo_id,'original':target,'quarantined':qpath,
          'sha256':checksum,'grant_id':grant['grant_id'],'decider':grant['decider'],
          'actuator_id':actuator_id,'status':'pending'}
    # LAB ONLY: production must journal intent before the rename and recover partial moves.
    upath=_manifest_path(undo_id)
    with open(upath,'x') as f:json.dump(undo,f);f.flush();os.fsync(f.fileno())
    eventbus.append_event(actuator_id,'action_result',{'outcome':'quarantined','undo_id':undo_id,'grant_id':grant['grant_id']},key_path)
    return {'outcome':'quarantined','undo_id':undo_id}

def undo(undo_id,actuator_id,key_path):
    lab_only();_trusted_identity(actuator_id,key_path)
    path=_manifest_path(undo_id)
    with open(path) as f:undo_record=json.load(f)
    if undo_record.get('actuator_id')!=actuator_id:raise ValueError('actuator identity mismatch')
    if undo_record.get('status')!='pending':raise ValueError('undo already applied')
    src=undo_record['quarantined']; target=undo_record['original']
    if not os.path.isfile(src):raise ValueError('quarantined file unavailable')
    if digest(src)!=undo_record['sha256']:raise ValueError('checksum mismatch')
    if os.path.lexists(target):raise FileExistsError('refusing overwrite on undo')
    os.replace(src,target)
    undo_record['status']='restored'
    tmp=path+'.'+uuid.uuid4().hex+'.tmp'
    with open(tmp,'x') as f:json.dump(undo_record,f);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
    eventbus.append_event(actuator_id,'action_result',{'outcome':'restored','undo_id':undo_id},key_path)
    return {'outcome':'restored'}

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True)
    s=sub.add_parser('execute');s.add_argument('--actuator-id',required=True);s.add_argument('--key',required=True)
    s.add_argument('--detection-event',required=True);s.add_argument('--grant',required=True);s.add_argument('--target',required=True)
    s=sub.add_parser('undo');s.add_argument('--actuator-id',required=True);s.add_argument('--key',required=True);s.add_argument('undo_id')
    a=p.parse_args()
    try:
        if a.cmd=='undo': print(json.dumps(undo(a.undo_id,a.actuator_id,a.key)))
        else:
            with open(GRANT.path_for(a.grant)) as f: g=json.load(f)
            rec=next((x for x in eventbus.read_events() if x['event']['event_id']==a.detection_event),None)
            if rec is None:raise ValueError('refused: detection not found')
            print(json.dumps(do_quarantine(a.target,g,rec,a.actuator_id,a.key)))
    except Exception as exc:
        print(json.dumps({'outcome':'refused','error':f'{type(exc).__name__}: {exc}'}))
        sys.exit(1)
if __name__=='__main__':main()
