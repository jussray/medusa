#!/usr/bin/env python3
"""LAB-ONLY deterministic rule matcher. Emits no actions."""
from __future__ import annotations
import hashlib, json, re, yaml


def load_rules(paths):
    rules=[]; rulesets=[]
    for path in paths:
        with open(path,encoding='utf-8') as f:doc=yaml.safe_load(f)
        if not isinstance(doc,dict) or not isinstance(doc.get('rules'),list):raise ValueError('ruleset must contain rules')
        if not doc.get('ruleset_id') or not doc.get('version'):raise ValueError('ruleset id/version missing')
        raw=open(path,'rb').read(); dig=hashlib.sha256(raw).hexdigest()
        for rule in doc['rules']:
            if not isinstance(rule,dict) or not all(k in rule for k in ('id','severity','when','evidence_tag')):
                raise ValueError('invalid rule')
            if rule['severity'] not in ('Low','Medium','High','Critical') or rule['evidence_tag'] not in ('VERIFIED','INFERRED','UNVERIFIED'):
                raise ValueError('invalid severity/evidence tag')
            rules.append({**rule,'ruleset_id':doc['ruleset_id'],'ruleset_version':doc['version'],'ruleset_sha256':dig})
        rulesets.append(doc)
    return rules,rulesets

def load_baseline():return {}

def evaluate_rule(rule,raw_events,baseline):
    conds=rule.get('when',{}).get('all',[])
    if not isinstance(conds,list) or not conds: raise ValueError('empty rule')
    matches=[]
    for e in raw_events:
        if e.get('event_type')!='fs_change': continue
        satisfied=True
        for c in conds:
            if 'event_type' in c and c['event_type']!=e['event_type']: satisfied=False;break
            if 'where' in c:
                if not all(e['payload'].get(k)==v for k,v in c['where'].items()):satisfied=False;break
            if 'path_matches' in c:
                if not re.search(c['path_matches'], e['payload'].get('path','')):satisfied=False;break
        if satisfied:matches.append(e)
    if not matches:return None
    # Every distinct evidence event gets its own detection, latest first.
    e=matches[-1]
    return {'rule_id':rule['id'],'ruleset_id':rule['ruleset_id'],
            'ruleset_version':rule['ruleset_version'],'ruleset_sha256':rule['ruleset_sha256'],
            'severity':rule['severity'],'confidence':rule.get('confidence','medium'),
            'evidence_tag':rule['evidence_tag'],'evidence_ref':[e['event_id']],
            'description':rule.get('description','')}
