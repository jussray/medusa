#!/usr/bin/env python3
"""LAB-ONLY, read-only polling filesystem sensor; no watchdog or network."""
from __future__ import annotations
import argparse, os, signal, sys, time, json, hashlib
import eventbus

RUN=True
def stop(_signum,_frame):
    global RUN
    RUN=False

def snapshot(dirs):
    found={}
    for root in dirs:
        base=os.path.realpath(root)
        for here,_,files in os.walk(base,followlinks=False):
            for name in files:
                p=os.path.join(here,name)
                if os.path.islink(p):continue
                try:
                    st=os.stat(p,follow_symlinks=False)
                    found[p]=(st.st_mtime_ns,st.st_size,st.st_ino)
                except OSError:pass
    return found

def main():
    eventbus.lab_only()
    p=argparse.ArgumentParser();p.add_argument('--config',required=True);a=p.parse_args()
    with open(a.config) as f: cfg=json.load(f)
    dirs=[r['path'] for r in cfg['watch']]
    identity=cfg['sensor_id'];key=cfg['key_path']
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    baseline=snapshot(dirs)
    eventbus.append_event(identity,'sensor_heartbeat',{'state':'running'},key)
    while RUN:
        time.sleep(0.15)
        nxt=snapshot(dirs)
        for path,metadata in nxt.items():
            if baseline.get(path)!=metadata:
                eventbus.append_event(identity,'fs_change',{'action':'write','path':path},key)
        baseline=nxt
    eventbus.append_event(identity,'sensor_heartbeat',{'state':'stopped'},key)
if __name__=='__main__':main()
