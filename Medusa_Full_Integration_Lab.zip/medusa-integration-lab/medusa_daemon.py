#!/usr/bin/env python3
"""Medusa Layer 6: local composition/supervisor (integration candidate; not released).

Offline control plane. Other Medusa layers are separate runtime dependencies.
Never infer authorization from a detection; grants and scope are checked by actuator.
"""
from __future__ import annotations
import argparse
import base64
import fcntl
import hashlib
import importlib
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

VERSION = "1.2.1-L6-local"
SEVERITY_ORDER = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
DEFAULT_LOOKBACK_S = 300
DEDUP_TTL_S = 3600


def die(message, code=2):
    print(f"medusa_daemon: {message}", file=sys.stderr)
    raise SystemExit(code)


def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def atomic_write(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + f".{os.getpid()}.tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
        _fsync_dir(os.path.dirname(path) or ".")
    except BaseException:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


def _fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def intent_path(cfg, detection_id, grant_id, target):
    """Deterministic action claim, scoped to the local daemon state directory."""
    if not cfg.get("state_dir"):
        raise ValueError("state_dir required for durable action intent")
    key = hashlib.sha256(json.dumps(
        [detection_id, grant_id, os.path.abspath(target)],
        separators=(",", ":"), ensure_ascii=False,
    ).encode()).hexdigest()
    directory = os.path.join(cfg["state_dir"], "action_intents")
    return os.path.join(directory, key + ".json"), key


def reserve_action_intent(cfg, detection_id, grant_id, target):
    """Exclusive, durable intent BEFORE any actuator side effect."""
    path, key = intent_path(cfg, detection_id, grant_id, target)
    os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
    record = {"idempotency_key": key, "detection_event_id": detection_id,
              "grant_id": grant_id, "target": target, "started_at": now_iso(),
              "state": "pending"}
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        fd = os.open(path, flags, 0o600)
    except FileExistsError:
        return None, key
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(json.dumps(record, sort_keys=True).encode())
            fh.flush()
            os.fsync(fh.fileno())
        _fsync_dir(os.path.dirname(path))
    except BaseException:
        # An uncertain claim is left in place, never silently released.
        raise
    return path, key


def finish_action_intent(path, state, outcome):
    with open(path, encoding="utf-8") as fh:
        record = json.load(fh)
    if record.get("state") != "pending":
        raise RuntimeError("intent is not pending; refusing transition")
    record.update({"state": state, "outcome": outcome, "completed_at": now_iso()})
    atomic_write(path, json.dumps(record, indent=2, sort_keys=True).encode())


def recover_pending_intents(cfg, m):
    """Do not replay uncertain actions after interruption; escalate once."""
    directory = os.path.join(cfg["state_dir"], "action_intents")
    if not os.path.isdir(directory):
        return 0
    count = 0
    for filename in sorted(os.listdir(directory)):
        if not filename.endswith(".json"):
            continue
        path = os.path.join(directory, filename)
        with open(path, encoding="utf-8") as fh:
            intent = json.load(fh)
        if intent.get("state") != "pending":
            continue
        emit(cfg, m, "action_request", {
            "detection_event_id": intent["detection_event_id"],
            "grant_id": intent["grant_id"],
            "reason": "action state unknown after restart; manual review required",
            "idempotency_key": intent["idempotency_key"],
        })
        finish_action_intent(path, "escalated", "unknown_after_restart")
        count += 1
    return count


def load_json(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def bootstrap(cfg):
    env = {
        "MEDUSA_BUS_DIR": cfg["bus_dir"],
        "MEDUSA_TRUSTED_SENSORS": cfg["trusted_sensors"],
        "MEDUSA_TRUSTED_SIGNERS": cfg["trusted_signers"],
        "MEDUSA_TRUSTED_ANCHORS": cfg["trusted_anchors"],
        "MEDUSA_GRANTS_DIR": cfg["grants_dir"],
        "MEDUSA_QUARANTINE_DIR": cfg["quarantine_dir"],
        "MEDUSA_UNDO_DIR": cfg["undo_dir"],
        "MEDUSA_DETECT_DIR": cfg["detect_dir"],
        "MEDUSA_ACTUATOR_DIR": cfg["state_dir"],
    }
    os.environ.update(env)
    for name in ("eventbus", "detect", "actuator", "authority_grant"):
        if name in sys.modules:
            importlib.reload(sys.modules[name])
    return SimpleNamespace(
        bus=importlib.import_module("eventbus"),
        detect=importlib.import_module("detect"),
        actuator=importlib.import_module("actuator"),
        grant=importlib.import_module("authority_grant"),
    )


def acquire_singleton(cfg):
    os.makedirs(cfg["state_dir"], exist_ok=True)
    lock_path = os.path.join(cfg["state_dir"], "daemon.lock")
    flags = os.O_RDWR | os.O_CREAT
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(lock_path, flags, 0o600)
    fh = os.fdopen(fd, "r+")
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        fh.close()
        die(f"another daemon holds {lock_path}; refusing to start")
    fh.seek(0)
    fh.truncate()
    fh.write(f"{os.getpid()}\n")
    fh.flush()
    return fh


def _pub_b64_from_pem(path):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    with open(path, "rb") as fh:
        private = serialization.load_pem_private_key(fh.read(), password=None)
    if not isinstance(private, Ed25519PrivateKey):
        raise ValueError("key is not Ed25519")
    raw = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(raw).decode("ascii")


def _valid_identity(registered, sid, key_path, label, failures):
    if not sid or sid not in registered:
        failures.append(f"{label}: {sid!r} not registered")
    elif not key_path or not os.path.isfile(key_path):
        failures.append(f"{label}: key missing: {key_path!r}")
    else:
        try:
            if _pub_b64_from_pem(key_path) != registered[sid]:
                failures.append(f"{label}: key does not match registered key for {sid!r}")
        except (OSError, ValueError, TypeError) as exc:
            failures.append(f"{label}: invalid key ({type(exc).__name__})")


def preflight(cfg, m):
    fails, warns = [], []
    for key in ("bus_dir", "quarantine_dir", "undo_dir", "detect_dir", "state_dir"):
        path = cfg.get(key)
        if not path or not os.path.isabs(path):
            fails.append(f"{key}: absolute path required")
            continue
        try:
            os.makedirs(path, exist_ok=True)
            probe = os.path.join(path, f".preflight.{os.getpid()}")
            with open(probe, "x", encoding="utf-8") as fh:
                fh.write("ok")
            os.unlink(probe)
        except OSError as exc:
            fails.append(f"{key}: not writable ({type(exc).__name__})")
    for key in ("trusted_sensors", "trusted_signers", "trusted_anchors"):
        if not os.path.isfile(cfg.get(key, "")):
            fails.append(f"{key}: missing trusted file")
    if fails:
        return fails, warns

    try:
        ts = load_json(cfg["trusted_sensors"])
        registered = {s["sensor_id"]: s["public_key_b64"] for s in ts["sensors"]}
        if len(registered) != len(ts["sensors"]):
            fails.append("duplicate trusted sensor ID")
    except (TypeError, KeyError, ValueError, json.JSONDecodeError):
        return ["trusted_sensors: invalid structure"], warns

    for sensor in cfg.get("sensors", []):
        config_path = sensor.get("config", "")
        if not os.path.isfile(config_path):
            fails.append(f"sensor {sensor.get('name')}: config missing")
            continue
        try:
            sc = load_json(config_path)
            _valid_identity(registered, sc.get("sensor_id"), sc.get("key_path"),
                            f"sensor {sensor.get('name')}", fails)
        except (ValueError, TypeError, OSError, json.JSONDecodeError):
            fails.append(f"sensor {sensor.get('name')}: invalid config")
        mod = sensor.get("module", "")
        if not mod.isidentifier() or mod not in ("fs_sensor", "config_sensor", "ci_sensor"):
            fails.append(f"sensor {sensor.get('name')}: unsupported module")

    rules = cfg.get("rulesets", [])
    if not rules:
        fails.append("no rulesets declared")
    for path in rules:
        if not os.path.isfile(path):
            fails.append(f"ruleset missing: {path}")
            continue
        try:
            m.detect.load_rules([path])
            _ruleset_lookback(path)
        except (Exception, SystemExit) as exc:
            fails.append(f"ruleset invalid: {path} ({type(exc).__name__})")

    actuator = cfg.get("actuator", {})
    _valid_identity(registered, actuator.get("sensor_id"), actuator.get("key_path"), "actuator", fails)
    _valid_identity(registered, cfg.get("detect_sensor_id"), cfg.get("detect_key"), "detect", fails)

    policies = cfg.get("action_policy", [])
    if not policies:
        fails.append("no action_policy declared")
    for i, p in enumerate(policies):
        ac = p.get("action_class")
        if ac not in ("quarantine_file", "escalate_only"):
            fails.append(f"action_policy[{i}]: unsupported action_class {ac!r}")
        if not p.get("match") or not isinstance(p["match"], dict):
            fails.append(f"action_policy[{i}]: missing match")
        if ac == "quarantine_file" and p.get("target_field") != "path":
            fails.append(f"action_policy[{i}]: quarantine target_field must be 'path'")
        severity = p.get("match", {}).get("min_severity")
        if severity is not None and severity not in SEVERITY_ORDER:
            fails.append(f"action_policy[{i}]: unknown min_severity")

    count = 0
    grants_dir = cfg.get("grants_dir", "")
    if os.path.isdir(grants_dir):
        for name in os.listdir(grants_dir):
            if not name.endswith(".grant.json"):
                continue
            try:
                g = load_json(os.path.join(grants_dir, name))
                if g.get("revoked_at"):
                    continue
                ok, _ = m.grant.verify_grant(g, m.grant.load_trusted())
                if ok:
                    count += 1
            except (Exception, SystemExit):
                continue
    if not count:
        warns.append("no active grants; daemon will escalate (not act) on detections")
    return fails, warns


def apply_policy(detection, policy):
    det = detection["payload"]
    level = SEVERITY_ORDER.get(det.get("severity"))
    if level is None:
        raise ValueError("unknown detection severity")
    matches = []
    for p in policy:
        m = p["match"]
        if "rule_id" in m and m["rule_id"] != det.get("rule_id"):
            continue
        threshold = m.get("min_severity")
        if threshold is not None:
            if threshold not in SEVERITY_ORDER:
                raise ValueError("unknown policy severity")
            if level < SEVERITY_ORDER[threshold]:
                continue
        matches.append(p)
    if not matches:
        return None
    if any(p.get("action_class") == "escalate_only" for p in matches):
        return "escalate_only", None
    first = matches[0]
    return first.get("action_class", "escalate_only"), first.get("target_field")


def find_evidence_target(detection, target_field, events_by_id):
    targets = set()
    if not target_field:
        return targets
    for eid in detection["payload"].get("evidence_ref", []):
        event = events_by_id.get(eid)
        if not event:
            continue
        payload = event.get("payload", {})
        target = payload.get(target_field) if isinstance(payload, dict) else None
        if isinstance(target, str) and target:
            targets.add(target)
    return targets


def state_path(cfg, filename):
    return os.path.join(cfg["state_dir"], filename)


def load_cursor(cfg):
    return load_json(state_path(cfg, "cursor.json"), {"last_detection_event_id": None})


def save_cursor(cfg, cursor):
    atomic_write(state_path(cfg, "cursor.json"), json.dumps(cursor, indent=2).encode())


def load_watermark(cfg):
    return load_json(state_path(cfg, "watermark.json"),
                     {"last_scan_observed_at": None, "recent_detections": {}})


def save_watermark(cfg, watermark):
    atomic_write(state_path(cfg, "watermark.json"), json.dumps(watermark, indent=2).encode())


class CursorIntegrityError(RuntimeError):
    pass


def collect_new_detections(cfg, m):
    entries = list(m.bus.read_events())
    cursor = load_cursor(cfg)
    last = cursor.get("last_detection_event_id")
    if last is not None:
        ids = {rec["event"]["event_id"] for rec in entries}
        if last not in ids:
            raise CursorIntegrityError(f"cursor references missing event {last!r}")
    out = []
    hit = last is None
    for rec in entries:
        e = rec["event"]
        if e.get("event_type") != "detection_feedback":
            continue
        if hit:
            out.append(rec)
        elif e.get("event_id") == last:
            hit = True
    if last is not None and not hit:
        raise CursorIntegrityError("cursor points to non-detection event")
    return out


def emit(cfg, m, event_type, payload):
    m.bus.append_event(cfg["actuator"]["sensor_id"], event_type, payload,
                       cfg["actuator"]["key_path"])


def emit_pipeline_run(cfg, m, outcome, details=None):
    emit(cfg, m, "pipeline_run", {"outcome": outcome, "at": now_iso(), **(details or {})})


def escalate(cfg, m, detection, reason):
    emit(cfg, m, "action_request", {
        "detection_event_id": detection["event"]["event_id"],
        "rule_id": detection["payload"].get("rule_id"),
        "severity": detection["payload"].get("severity"),
        "reason": reason,
    })


def dispatch_action(action_class, target, grant, detection, cfg, m):
    if action_class == "quarantine_file":
        return m.actuator.do_quarantine(target, grant, detection,
                                        cfg["actuator"]["sensor_id"],
                                        cfg["actuator"]["key_path"])
    raise NotImplementedError(f"action class {action_class!r} has no dispatcher")


def try_act(cfg, m, detection, action_class, target_field, events_by_id):
    grants = []
    grants_dir = cfg.get("grants_dir", "")
    if os.path.isdir(grants_dir):
        for filename in sorted(os.listdir(grants_dir)):
            if not filename.endswith(".grant.json"):
                continue
            try:
                grant = load_json(os.path.join(grants_dir, filename))
                if grant.get("action_class") != action_class or grant.get("revoked_at"):
                    continue
                ok, _ = m.grant.verify_grant(grant, m.grant.load_trusted())
                if ok:
                    grants.append(grant)
            except (Exception, SystemExit):
                continue
    if not grants:
        escalate(cfg, m, detection, f"no valid grant for {action_class}")
        return "escalated: no grant"
    targets = find_evidence_target(detection, target_field, events_by_id)
    if not targets:
        escalate(cfg, m, detection, f"no {target_field} in evidence")
        return "escalated: no target"
    for target in sorted(targets):
        for grant in grants:
            resolved = os.path.realpath(target)
            ok, _ = m.actuator.path_in_scope(resolved, grant["target_scope"],
                                               grant.get("excluded_paths"))
            if not ok:
                continue
            d = detection["payload"]
            if m.actuator.EVIDENCE_ORDER[d["evidence_tag"]] < m.actuator.EVIDENCE_ORDER[grant["requires_evidence_tag"]]:
                continue
            if m.actuator.SEVERITY_ORDER[d["severity"]] < m.actuator.SEVERITY_ORDER[grant["requires_detection_severity"]]:
                continue
            # The claim is durable before invoking any potentially irreversible effect.
            claim, key = reserve_action_intent(cfg, detection["event"]["event_id"],
                                               grant["grant_id"], target)
            if claim is None:
                escalate(cfg, m, detection, "existing action intent: manual review required")
                return "escalated: duplicate intent"
            try:
                result = dispatch_action(action_class, target, grant, detection, cfg, m)
            except Exception as exc:
                finish_action_intent(claim, "done", f"error:{type(exc).__name__}")
                emit(cfg, m, "action_result", {
                    "action_class": action_class, "grant_id": grant["grant_id"],
                    "detection_event_id": detection["event"]["event_id"],
                    "target": target, "outcome": "error",
                    "reason": f"{type(exc).__name__}",
                })
                escalate(cfg, m, detection, f"action failed: {type(exc).__name__}")
                return "escalated: action_failed"
            outcome = result.get("outcome", "unknown")
            finish_action_intent(claim, "done", outcome)
            emit(cfg, m, "action_result", {
                "action_class": action_class, "grant_id": grant["grant_id"],
                "detection_event_id": detection["event"]["event_id"],
                "target": target, "outcome": outcome,
                "reason": result.get("reason", ""), "undo_id": result.get("undo_id", ""),
            })
            # Only a documented successful quarantine counts as an action.
            # Unknown/refused outcomes are never promoted to success.
            if outcome != "quarantined":
                escalate(cfg, m, detection, f"action returned non-success: {outcome}")
                return "escalated: action_refused"
            return "acted: quarantined"
    escalate(cfg, m, detection, "no grant matched scope/evidence/severity")
    return "escalated: no grant matched"


def dedup_key(rule_id, evidence_ref):
    return hashlib.sha256((rule_id + "|" + "|".join(sorted(evidence_ref))).encode()).hexdigest()


def _parse_iso(s):
    dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError("timestamp must contain timezone")
    return dt


def _ruleset_lookback(path):
    import yaml
    with open(path, encoding="utf-8") as fh:
        doc = yaml.safe_load(fh)
    if not isinstance(doc, dict):
        raise ValueError("ruleset not a mapping")
    n = doc.get("lookback_s", DEFAULT_LOOKBACK_S)
    if type(n) is not int or n < 1 or n > 86400:
        raise ValueError("lookback_s must be integer 1..86400")
    return n


def run_detection_once(cfg, m):
    watermark = load_watermark(cfg)
    rules, _ = m.detect.load_rules(cfg["rulesets"])
    lookback = max((_ruleset_lookback(r) for r in cfg["rulesets"]), default=DEFAULT_LOOKBACK_S)
    records = list(m.bus.read_events())
    events = [r["event"] | {"payload": r["payload"]} for r in records]
    # The signed bus is the durable detection ledger. Relying on a separate
    # watermark alone can duplicate detections after a crash between bus append
    # and watermark persistence, or after the dedup cache expires.
    bus_dedup = {
        dedup_key(r["payload"]["rule_id"], r["payload"]["evidence_ref"])
        for r in records
        if r["event"].get("event_type") == "detection_feedback"
        and isinstance(r.get("payload"), dict)
        and isinstance(r["payload"].get("rule_id"), str)
        and isinstance(r["payload"].get("evidence_ref"), list)
    }
    now = datetime.now(timezone.utc)
    # IMPORTANT: dedup spans a longer window than lookback, but is not exactly-once
    # across arbitrary restarts, changes to rules, or evidence replays.
    recent = watermark.get("recent_detections", {})
    ttl = timedelta(seconds=DEDUP_TTL_S)
    recent = {k: v for k, v in recent.items() if now - _parse_iso(v["seen_at"]) < ttl}
    last = watermark.get("last_scan_observed_at")
    if last:
        cutoff = _parse_iso(last) - timedelta(seconds=lookback)
        candidates = [e for e in events if _parse_iso(e["observed_at"]) >= cutoff]
    else:
        candidates = events

    emitted, failures = 0, 0
    baseline = m.detect.load_baseline()
    for rule in rules:
        try:
            detection = m.detect.evaluate_rule(rule, candidates, baseline)
        except Exception as exc:
            failures += 1
            emit(cfg, m, "sensor_error", {
                "reason": "rule_evaluation_failed", "rule_id": rule.get("id", "?"),
                "error_class": type(exc).__name__,
            })
            continue
        if not detection:
            continue
        key = dedup_key(detection["rule_id"], detection["evidence_ref"])
        if key in recent or key in bus_dedup:
            continue
        payload = {key: detection[key] for key in (
            "rule_id", "ruleset_id", "ruleset_version", "ruleset_sha256",
            "severity", "confidence", "evidence_tag", "evidence_ref",
        )}
        payload["description"] = detection.get("description", "")
        if "group" in detection:
            payload["group"] = detection["group"]
        if "count" in detection:
            payload["count"] = detection["count"]
        m.bus.append_event(cfg["detect_sensor_id"], "detection_feedback", payload, cfg["detect_key"])
        recent[key] = {"rule_id": detection["rule_id"], "seen_at": now_iso()}
        bus_dedup.add(key)
        emitted += 1
    watermark["recent_detections"] = recent
    if events:
        watermark["last_scan_observed_at"] = max(e["observed_at"] for e in events)
    save_watermark(cfg, watermark)
    if failures:
        emit_pipeline_run(cfg, m, "rule_failures", {"count": failures})
    return emitted, failures


def process_detections(cfg, m):
    records = list(m.bus.read_events())
    by_id = {r["event"]["event_id"]: r for r in records}
    try:
        new = collect_new_detections(cfg, m)
    except CursorIntegrityError as exc:
        emit_pipeline_run(cfg, m, "cursor_integrity_failure", {"error_class": type(exc).__name__})
        raise
    cursor = load_cursor(cfg)
    processed = 0
    for rec in new:
        detection = {"event": rec["event"], "payload": rec["payload"]}
        p = apply_policy(detection, cfg["action_policy"])
        if p is None:
            emit(cfg, m, "policy_unmatched", {
                "detection_event_id": detection["event"]["event_id"],
                "rule_id": detection["payload"].get("rule_id"),
                "severity": detection["payload"].get("severity"),
            })
        elif p[0] == "escalate_only":
            escalate(cfg, m, detection, "policy: escalate_only")
        else:
            try_act(cfg, m, detection, p[0], p[1], by_id)
        cursor["last_detection_event_id"] = detection["event"]["event_id"]
        save_cursor(cfg, cursor)
        processed += 1
    return processed


class Daemon:
    def __init__(self, cfg, modules):
        self.cfg, self.m = cfg, modules
        self.running = True
        self.stop_requested = 0
        self.sensor_procs = {}
        self.lock_fh = None

    def handle_signal(self, signum, _frame):
        self.stop_requested += 1
        self.running = False
        if self.stop_requested > 1:
            for p in self.sensor_procs.values():
                try:
                    p.terminate()
                except OSError:
                    pass

    def start_sensors(self):
        for sensor in self.cfg.get("sensors", []):
            module = sensor["module"]
            if module not in ("fs_sensor", "config_sensor", "ci_sensor"):
                raise RuntimeError("unsupported sensor module")
            module_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), module + ".py")
            if not os.path.isfile(module_file):
                raise RuntimeError(f"sensor module missing: {module}")
            with open(os.path.join(self.cfg["state_dir"], f"sensor-{sensor['name']}.log"), "a", encoding="utf-8") as log:
                proc = subprocess.Popen(
                    [sys.executable, module_file, "--config", sensor["config"]],
                    stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                )
            self.sensor_procs[sensor["name"]] = proc

    def stop_sensors(self):
        for p in self.sensor_procs.values():
            if p.poll() is None:
                p.terminate()
        deadline = time.monotonic() + 10
        for p in self.sensor_procs.values():
            try:
                p.wait(timeout=max(0, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait(timeout=5)

    def run(self):
        self.lock_fh = acquire_singleton(self.cfg)
        previous_term = signal.signal(signal.SIGTERM, self.handle_signal)
        previous_int = signal.signal(signal.SIGINT, self.handle_signal)
        try:
            # Crash recovery happens before new sensor events or side effects.
            recover_pending_intents(self.cfg, self.m)
            self.start_sensors()
            last = 0
            while self.running:
                if time.monotonic() - last >= self.cfg["detect_interval_s"]:
                    last = time.monotonic()
                    try:
                        emitted, failures = run_detection_once(self.cfg, self.m)
                        if failures:
                            emit_pipeline_run(self.cfg, self.m, "degraded", {"rule_failures": failures})
                            # Fail closed: do not attempt new actions when any rule failed.
                        else:
                            processed = process_detections(self.cfg, self.m)
                            emit_pipeline_run(self.cfg, self.m, "ok", {
                                "detections_emitted": emitted, "detections_processed": processed,
                            })
                    except CursorIntegrityError:
                        self.running = False
                    except Exception as exc:
                        emit_pipeline_run(self.cfg, self.m, "error", {"error_class": type(exc).__name__})
                        self.running = False
                if self.running:
                    time.sleep(0.25)
        finally:
            try:
                self.stop_sensors()
                emit_pipeline_run(self.cfg, self.m, "shutdown")
            finally:
                signal.signal(signal.SIGTERM, previous_term)
                signal.signal(signal.SIGINT, previous_int)
                self.lock_fh.close()


def _load_cfg(args):
    if not os.path.isfile(args.config):
        die(f"config missing: {args.config}")
    cfg = load_json(args.config)
    if not isinstance(cfg, dict):
        die("composition must be an object")
    return cfg


def cmd_preflight(args):
    cfg = _load_cfg(args)
    m = bootstrap(cfg)
    failures, warnings = preflight(cfg, m)
    for warning in warnings:
        print(f"WARN: {warning}")
    if failures:
        print("PREFLIGHT: FAIL")
        for failure in failures:
            print(f"  - {failure}")
        raise SystemExit(1)
    print("PREFLIGHT: OK")


def cmd_run(args):
    cfg = _load_cfg(args)
    if not cfg.get("detect_key") or not cfg.get("detect_sensor_id"):
        die("composition missing detect signing identity")
    m = bootstrap(cfg)
    failures, warnings = preflight(cfg, m)
    if failures:
        for failure in failures:
            print(f"PREFLIGHT: FAIL: {failure}", file=sys.stderr)
        raise SystemExit(2)
    for warning in warnings:
        print(f"WARN: {warning}", file=sys.stderr)
    Daemon(cfg, m).run()


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("run", "preflight"):
        parser = sub.add_parser(name)
        parser.add_argument("--config", required=True)
    args = p.parse_args(argv)
    {"run": cmd_run, "preflight": cmd_preflight}[args.cmd](args)


if __name__ == "__main__":
    main()
