"""Crash-boundary idempotency contract. LAB synthetic test doubles, real filesystem."""
import json
import pathlib
import sys
from types import SimpleNamespace
import pytest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import medusa_daemon as D


def setup_case(tmp_path):
    grants=tmp_path/'grants';grants.mkdir()
    (grants/'g1.grant.json').write_text(json.dumps({
        'grant_id':'g1','action_class':'quarantine_file','target_scope':str(tmp_path),
        'requires_evidence_tag':'VERIFIED','requires_detection_severity':'High'}))
    cfg={'grants_dir':str(grants),'state_dir':str(tmp_path/'state'),
         'actuator':{'sensor_id':'a1','key_path':'synthetic'}}
    emitted=[]
    m=SimpleNamespace(
        bus=SimpleNamespace(append_event=lambda sid,typ,payload,key:emitted.append((typ,payload))),
        grant=SimpleNamespace(verify_grant=lambda *_:(True,'valid'),load_trusted=lambda:{}),
        actuator=SimpleNamespace(path_in_scope=lambda *_:(True,'ok'),
            EVIDENCE_ORDER={'VERIFIED':3},SEVERITY_ORDER={'High':3}),
    )
    target=str(tmp_path/'target.txt')
    det={'event':{'event_id':'det-1'},'payload':{
        'rule_id':'r','severity':'High','evidence_tag':'VERIFIED','evidence_ref':['e1']}}
    by_id={'e1':{'payload':{'path':target}}}
    return cfg,m,det,by_id,emitted


def test_success_is_durable_and_replay_does_not_dispatch(tmp_path,monkeypatch):
    cfg,m,det,by_id,emissions=setup_case(tmp_path)
    attempts=[]
    def dispatch(*_):
        attempts.append(1)
        return {'outcome':'quarantined','undo_id':'u1'}
    monkeypatch.setattr(D,'dispatch_action',dispatch)
    assert D.try_act(cfg,m,det,'quarantine_file','path',by_id)=='acted: quarantined'
    assert len(attempts)==1
    intents=list((tmp_path/'state'/'action_intents').glob('*.json'))
    assert len(intents)==1
    assert json.loads(intents[0].read_text())['state']=='done'
    again=D.try_act(cfg,m,det,'quarantine_file','path',by_id)
    assert again.startswith('escalated: duplicate intent')
    assert len(attempts)==1
    assert any(t=='action_request' for t,_ in emissions)


def test_crash_leaves_pending_and_restart_escalates_without_reexecution(tmp_path,monkeypatch):
    cfg,m,det,by_id,emissions=setup_case(tmp_path)
    attempts=[]
    def crash(*_):
        attempts.append(1)
        raise KeyboardInterrupt('simulated process interruption after intent')
    monkeypatch.setattr(D,'dispatch_action',crash)
    with pytest.raises(KeyboardInterrupt):
        D.try_act(cfg,m,det,'quarantine_file','path',by_id)
    files=list((tmp_path/'state'/'action_intents').glob('*.json'))
    assert len(files)==1
    assert json.loads(files[0].read_text())['state']=='pending'
    assert D.recover_pending_intents(cfg,m)==1
    assert json.loads(files[0].read_text())['state']=='escalated'
    assert D.recover_pending_intents(cfg,m)==0
    assert [t for t,_ in emissions].count('action_request')==1
    monkeypatch.setattr(D,'dispatch_action',lambda *_: pytest.fail('must not retry ambiguous action'))
    assert D.try_act(cfg,m,det,'quarantine_file','path',by_id).startswith('escalated: duplicate intent')
