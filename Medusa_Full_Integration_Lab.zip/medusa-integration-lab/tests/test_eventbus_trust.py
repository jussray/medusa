"""Only explicit trust enrollment may authorize a signing sensor."""
import os, sys, pathlib, json
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import eventbus

def test_implicit_self_registration_cannot_bypass_trusted_sensor_roster(tmp_path,monkeypatch):
    bus=tmp_path/'bus'; bus.mkdir()
    trust=tmp_path/'trusted_sensors.json';trust.write_text('{"sensors":[]}')
    monkeypatch.setenv('MEDUSA_LAB_MODE','1')
    monkeypatch.setenv('MEDUSA_BUS_DIR',str(bus))
    monkeypatch.setenv('MEDUSA_TRUSTED_SENSORS',str(trust))
    key=Ed25519PrivateKey.generate()
    priv=tmp_path/'new.pem'
    priv.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    with pytest.raises(ValueError,match='untrusted'):
        eventbus.append_event('rogue','sensor_heartbeat',{'state':'running'},str(priv),allow_self_registration=True)
    assert json.loads(trust.read_text())=={'sensors':[]}
    assert not (bus/'events.jsonl').exists()
