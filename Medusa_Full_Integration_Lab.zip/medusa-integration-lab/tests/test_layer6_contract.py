"""Layer 6 isolated tests: behavior, not claims of full pipeline integration."""
import base64
import json
import os
import pathlib
import subprocess
import sys
from types import SimpleNamespace

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import medusa_daemon as D


def fixture_key(tmp, name):
    private = Ed25519PrivateKey.generate()
    pem = private.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    key_file = tmp / f"{name}.pem"
    key_file.write_bytes(pem)
    pub = base64.b64encode(private.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()
    return str(key_file), pub


def write_json(path, data):
    path.write_text(json.dumps(data))
    return str(path)


def test_sticky_critical_escalation_and_high_quarantine():
    policies = [
        {"match": {"rule_id": "fs-1", "min_severity": "High"},
         "action_class": "quarantine_file", "target_field": "path"},
        {"match": {"min_severity": "Critical"}, "action_class": "escalate_only"},
    ]
    assert D.apply_policy({"payload": {"rule_id": "fs-1", "severity": "High"}}, policies) == ("quarantine_file", "path")
    assert D.apply_policy({"payload": {"rule_id": "fs-1", "severity": "Critical"}}, policies) == ("escalate_only", None)


def test_unknown_detection_severity_fails_closed():
    with pytest.raises(ValueError, match="unknown detection severity"):
        D.apply_policy({"payload": {"rule_id": "fs-1", "severity": "unknown"}}, [])


def test_missing_cursor_is_integrity_error(tmp_path):
    cfg = {"state_dir": str(tmp_path)}
    D.save_cursor(cfg, {"last_detection_event_id": "removed"})
    fake = SimpleNamespace(bus=SimpleNamespace(read_events=lambda: []))
    with pytest.raises(D.CursorIntegrityError, match="missing event"):
        D.collect_new_detections(cfg, fake)


def test_duplicate_supervisor_is_refused_in_second_process(tmp_path):
    cfg = {"state_dir": str(tmp_path)}
    lock = D.acquire_singleton(cfg)
    try:
        code = (
            "import medusa_daemon as d;"
            f"d.acquire_singleton({{'state_dir': {str(tmp_path)!r}}})"
        )
        env = {**os.environ, "PYTHONPATH": str(ROOT)}
        result = subprocess.run([sys.executable, "-c", code], capture_output=True,
                                text=True, env=env, timeout=10)
        assert result.returncode == 2
        assert "another daemon holds" in result.stderr
    finally:
        lock.close()
    after = D.acquire_singleton(cfg)
    after.close()


def test_yaml_lookback_is_used_and_invalid_explicit_values_refused(tmp_path):
    path = tmp_path / "rules.yml"
    path.write_text("ruleset_id: demo\nlookback_s: 712\nrules: []\n")
    assert D._ruleset_lookback(str(path)) == 712
    path.write_text("ruleset_id: demo\nlookback_s: abc\nrules: []\n")
    with pytest.raises(ValueError, match="lookback_s"):
        D._ruleset_lookback(str(path))


def preflight_fixture(tmp_path, key_mismatch=False):
    keys = {name: fixture_key(tmp_path, name) for name in ("sensor", "detect", "act", "wrong")}
    registered = {"s1": keys["sensor"][1], "d1": keys["detect"][1], "a1": keys["act"][1]}
    trusted_sensors = write_json(tmp_path / "trusted_sensors.json", {
        "sensors": [{"sensor_id": k, "public_key_b64": v} for k, v in registered.items()]})
    trusted_signers = write_json(tmp_path / "trusted_signers.json", {"signers": []})
    trusted_anchors = write_json(tmp_path / "trusted_anchors.json", {"anchors": []})
    sensor_conf = write_json(tmp_path / "sensor.json", {"sensor_id": "s1", "key_path": keys["sensor"][0]})
    rules = tmp_path / "rules.yml"
    rules.write_text("ruleset_id: demo\nversion: '1'\nlookback_s: 400\nrules: []\n")
    cfg = {"bus_dir": str(tmp_path / "bus"), "quarantine_dir": str(tmp_path / "quarantine"),
           "undo_dir": str(tmp_path / "undo"), "detect_dir": str(tmp_path / "detectdir"),
           "state_dir": str(tmp_path / "state"), "trusted_sensors": trusted_sensors,
           "trusted_signers": trusted_signers, "trusted_anchors": trusted_anchors,
           "grants_dir": str(tmp_path / "grants"),
           "sensors": [{"name": "my-sensor", "module": "fs_sensor", "config": sensor_conf}],
           "rulesets": [str(rules)], "actuator": {"sensor_id": "a1", "key_path": keys["act"][0]},
           "detect_sensor_id": "d1",
           "detect_key": keys["wrong"][0] if key_mismatch else keys["detect"][0],
           "action_policy": [{"match": {"min_severity": "High"}, "action_class": "escalate_only"}]}
    modules = SimpleNamespace(detect=SimpleNamespace(load_rules=lambda _: ([], [])),
                              grant=SimpleNamespace(verify_grant=lambda *_: (False, "no"),
                                                    load_trusted=lambda: {}))
    return cfg, modules


def test_preflight_warns_without_grants(tmp_path):
    cfg, modules = preflight_fixture(tmp_path)
    failures, warnings = D.preflight(cfg, modules)
    assert failures == []
    assert any("no active grants" in w for w in warnings)


def test_detect_key_must_match_specified_sensor_identity(tmp_path):
    cfg, modules = preflight_fixture(tmp_path, key_mismatch=True)
    failures, _ = D.preflight(cfg, modules)
    assert any("detect" in e and "key does not match" in e for e in failures)


def test_action_failure_escalates_once_and_never_tries_second_grant(tmp_path, monkeypatch):
    grants_dir = tmp_path / "grants"
    grants_dir.mkdir()
    for i in (1, 2):
        write_json(grants_dir / f"{i}.grant.json", {
            "grant_id": f"g{i}", "action_class": "quarantine_file", "target_scope": str(tmp_path),
            "requires_evidence_tag": "VERIFIED", "requires_detection_severity": "High"})
    cfg = {"grants_dir": str(grants_dir), "state_dir": str(tmp_path / "state"),
           "actuator": {"sensor_id": "a1", "key_path": "synthetic.key"}}
    emissions, attempts = [], []
    m = SimpleNamespace(
        bus=SimpleNamespace(append_event=lambda sid, etype, payload, key: emissions.append((etype, payload))),
        grant=SimpleNamespace(verify_grant=lambda *_: (True, "ok"), load_trusted=lambda: {}),
        actuator=SimpleNamespace(path_in_scope=lambda *_: (True, "ok"),
                                 EVIDENCE_ORDER={"VERIFIED": 3}, SEVERITY_ORDER={"High": 3}))
    def broken_dispatch(action_class, target, grant, detection, cfg, m):
        attempts.append(grant["grant_id"])
        raise RuntimeError("synthetic dispatch failure")
    monkeypatch.setattr(D, "dispatch_action", broken_dispatch)
    det = {"event": {"event_id": "det-1"},
           "payload": {"rule_id": "r", "severity": "High", "evidence_tag": "VERIFIED",
                       "evidence_ref": ["source-1"]}}
    records = {"source-1": {"payload": {"path": str(tmp_path / "file.txt")}}}
    assert D.try_act(cfg, m, det, "quarantine_file", "path", records) == "escalated: action_failed"
    assert attempts == ["g1"]
    assert [e[0] for e in emissions] == ["action_result", "action_request"]


def test_rule_failure_records_signed_events_and_count(tmp_path):
    cfg = {"rulesets": [str(tmp_path / "rules.yml")], "state_dir": str(tmp_path),
           "actuator": {"sensor_id": "a1", "key_path": "test"},
           "detect_sensor_id": "detect", "detect_key": "test"}
    (tmp_path / "rules.yml").write_text("ruleset_id: demo\nlookback_s: 300\nrules: []\n")
    emitted = []
    bus = SimpleNamespace(read_events=lambda: [],
                          append_event=lambda sid, typ, payload, key: emitted.append((typ, payload)))
    def fail_evaluate(*_):
        raise ValueError("synthetic failure")
    detect = SimpleNamespace(load_rules=lambda _: ([{"id": "rule-1"}], []),
                             load_baseline=lambda: {}, evaluate_rule=fail_evaluate)
    assert D.run_detection_once(cfg, SimpleNamespace(bus=bus, detect=detect)) == (0, 1)
    assert [x[0] for x in emitted] == ["sensor_error", "pipeline_run"]
    assert emitted[-1][1]["outcome"] == "rule_failures"


def test_startup_exception_runs_cleanup_and_releases_lock(tmp_path, monkeypatch):
    cfg = {"state_dir": str(tmp_path), "detect_interval_s": 1}
    d = D.Daemon(cfg, SimpleNamespace())
    cleared = []
    monkeypatch.setattr(d, "start_sensors", lambda: (_ for _ in ()).throw(RuntimeError("startup failed")))
    monkeypatch.setattr(d, "stop_sensors", lambda: cleared.append("stopped"))
    monkeypatch.setattr(D, "emit_pipeline_run", lambda *_: cleared.append("shutdown"))
    with pytest.raises(RuntimeError, match="startup failed"):
        d.run()
    assert cleared == ["stopped", "shutdown"]
    lock = D.acquire_singleton(cfg)
    lock.close()


def test_degraded_detection_never_executes_actions_or_reports_ok(tmp_path, monkeypatch):
    cfg = {"state_dir": str(tmp_path), "detect_interval_s": 0}
    daemon = D.Daemon(cfg, SimpleNamespace())
    emissions = []
    monkeypatch.setattr(daemon, "start_sensors", lambda: None)
    monkeypatch.setattr(daemon, "stop_sensors", lambda: None)
    monkeypatch.setattr(D, "run_detection_once", lambda *_: (0, 1))
    monkeypatch.setattr(D, "process_detections", lambda *_: pytest.fail("actions must not proceed after rule failure"))
    def capture(cfg, modules, outcome, details=None):
        emissions.append(outcome)
        daemon.running = False
    monkeypatch.setattr(D, "emit_pipeline_run", capture)
    daemon.run()
    assert emissions == ["degraded", "shutdown"]


def test_existing_signed_detection_in_bus_prevents_restart_replay(tmp_path):
    cfg = {"rulesets": [str(tmp_path / "rules.yml")], "state_dir": str(tmp_path),
           "actuator": {"sensor_id": "a1", "key_path": "synthetic"},
           "detect_sensor_id": "d1", "detect_key": "synthetic"}
    (tmp_path / "rules.yml").write_text("ruleset_id: fs\nlookback_s: 300\nrules: []\n")
    t = D.now_iso()
    logs = [
        {"event": {"event_type": "fs_change", "event_id": "input1", "observed_at": t},
         "payload": {"path": "/synthetic/path"}},
        {"event": {"event_type": "detection_feedback", "event_id": "det-old", "observed_at": t},
         "payload": {"rule_id": "fs-1", "evidence_ref": ["input1"]}},
    ]
    emissions = []
    bus = SimpleNamespace(read_events=lambda: logs,
                          append_event=lambda *_: emissions.append(_))
    detection = {"rule_id": "fs-1", "evidence_ref": ["input1"],
                 "ruleset_id": "fs", "ruleset_version": "1", "ruleset_sha256": "sha",
                 "severity": "High", "confidence": "medium", "evidence_tag": "VERIFIED"}
    detect = SimpleNamespace(load_rules=lambda *_: ([{"id": "fs-1"}], None),
                             load_baseline=lambda: {}, evaluate_rule=lambda *_: detection)
    assert D.run_detection_once(cfg, SimpleNamespace(bus=bus, detect=detect)) == (0, 0)
    assert not emissions


def test_actuator_refusal_escalates_instead_of_reporting_acted(tmp_path):
    directory = tmp_path / "grants"
    directory.mkdir()
    write_json(directory / "1.grant.json", {
        "grant_id": "g1", "action_class": "quarantine_file", "target_scope": str(tmp_path),
        "requires_evidence_tag": "VERIFIED", "requires_detection_severity": "High"})
    cfg = {"grants_dir": str(directory), "state_dir": str(tmp_path / "state"),
           "actuator": {"sensor_id": "a", "key_path": "synthetic"}}
    emitted = []
    m = SimpleNamespace(
        bus=SimpleNamespace(append_event=lambda sid, typ, data, key: emitted.append((typ, data))),
        grant=SimpleNamespace(verify_grant=lambda *_: (True, "ok"), load_trusted=lambda: {}),
        actuator=SimpleNamespace(path_in_scope=lambda *_: (True, "ok"),
              EVIDENCE_ORDER={"VERIFIED": 3}, SEVERITY_ORDER={"High": 3},
              do_quarantine=lambda *_: {"outcome": "refused", "reason": "safe refusal"}))
    detection = {"event": {"event_id": "det1"}, "payload": {
        "rule_id": "r", "severity": "High", "evidence_tag": "VERIFIED", "evidence_ref": ["e1"]}}
    result = D.try_act(cfg, m, detection, "quarantine_file", "path",
                       {"e1": {"payload": {"path": str(tmp_path / "f")}}})
    assert result == "escalated: action_refused"
    assert [x[0] for x in emitted] == ["action_result", "action_request"]


def test_documented_successful_quarantine_returns_acted_without_escalation(tmp_path):
    directory = tmp_path / "grants"
    directory.mkdir()
    write_json(directory / "1.grant.json", {
        "grant_id": "g1", "action_class": "quarantine_file", "target_scope": str(tmp_path),
        "requires_evidence_tag": "VERIFIED", "requires_detection_severity": "High"})
    cfg = {"grants_dir": str(directory), "state_dir": str(tmp_path / "state"),
           "actuator": {"sensor_id": "a", "key_path": "synthetic"}}
    emissions = []
    m = SimpleNamespace(
        bus=SimpleNamespace(append_event=lambda sid, typ, data, key: emissions.append((typ, data))),
        grant=SimpleNamespace(verify_grant=lambda *_: (True, "ok"), load_trusted=lambda: {}),
        actuator=SimpleNamespace(path_in_scope=lambda *_: (True, "ok"),
              EVIDENCE_ORDER={"VERIFIED": 3}, SEVERITY_ORDER={"High": 3},
              do_quarantine=lambda *_: {"outcome": "quarantined", "undo_id": "undo1"}))
    detection = {"event": {"event_id": "det1"}, "payload": {
        "rule_id": "r", "severity": "High", "evidence_tag": "VERIFIED", "evidence_ref": ["e1"]}}
    result = D.try_act(cfg, m, detection, "quarantine_file", "path",
                       {"e1": {"payload": {"path": str(tmp_path / "f")}}})
    assert result == "acted: quarantined"
    assert [x[0] for x in emissions] == ["action_result"]
