#!/usr/bin/env python3
"""LAB-ONLY parallel event-bus append test (not a production load benchmark)."""
from __future__ import annotations
import argparse, base64, json, multiprocessing as mp, os, sys, tempfile, time
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import eventbus

def writer(i, barrier, key, count, results):
    try:
        barrier.wait(timeout=25)
        for j in range(count):
            eventbus.append_event('bench-sensor','sensor_heartbeat',{'writer':i,'number':j},key)
        results.put((i,None))
    except BaseException as exc:
        results.put((i,f'{type(exc).__name__}: {exc}'))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--writers',type=int,default=25)
    ap.add_argument('--events',type=int,default=10)
    a=ap.parse_args()
    if a.writers<1 or a.events<1:raise SystemExit(2)
    with tempfile.TemporaryDirectory(prefix='medusa-bus-lab-') as d:
        os.environ['MEDUSA_LAB_MODE']='1';os.environ['MEDUSA_BUS_DIR']=d+'/bus'
        os.environ['MEDUSA_TRUSTED_SENSORS']=d+'/sensors.json'
        os.environ['MEDUSA_TRUSTED_ANCHORS']=d+'/anchors.json'
        Path(d+'/bus').mkdir()
        Path(d+'/sensors.json').write_text('{"sensors":[]}')
        Path(d+'/anchors.json').write_text('{"anchors":[]}')
        key=Ed25519PrivateKey.generate(); keypath=d+'/key.pem'
        Path(keypath).write_bytes(key.private_bytes(serialization.Encoding.PEM,
                   serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        eventbus.register('bench-sensor',keypath)
        ctx=mp.get_context('fork');barrier=ctx.Barrier(a.writers);q=ctx.Queue()
        workers=[ctx.Process(target=writer,args=(i,barrier,keypath,a.events,q)) for i in range(a.writers)]
        begin=time.monotonic()
        for p in workers:p.start()
        for p in workers:p.join(timeout=45)
        for p in workers:
            if p.is_alive():p.terminate();p.join(5)
        errors=[p.pid for p in workers if p.exitcode!=0]
        responses=[q.get(timeout=3) for _ in range(a.writers)] if not errors else []
        records=eventbus.read_events();expected=a.writers*a.events
        valid=eventbus.verify_chain()['ok']
        seq=[r['event']['seq'] for r in records]
        unique_ids={r['event']['event_id'] for r in records}
        ok=(not errors and all(message is None for _,message in responses)
            and len(records)==expected and seq==list(range(expected))
            and len(unique_ids)==expected and valid)
        print(f'Writers={a.writers} events_per_writer={a.events} expected={expected} '
              f'actual={len(records)} worker_failures={len(errors)} chain={"PASS" if valid else "FAIL"} '
              f'elapsed_s={time.monotonic()-begin:.2f} result={"PASS" if ok else "FAIL"}')
        if not ok:
            print('Errors:',errors,responses[:5]);raise SystemExit(1)
if __name__=='__main__':main()
