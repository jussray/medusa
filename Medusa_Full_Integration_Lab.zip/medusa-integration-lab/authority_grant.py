#!/usr/bin/env python3
"""LAB-ONLY signed and revocable action grants."""
from __future__ import annotations
import argparse, base64, json, os, sys, uuid
from datetime import datetime, timedelta, timezone
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

ACTION_CLASSES=('quarantine_file',)
def canon(o):return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def now():return datetime.now(timezone.utc)
def timestamp(dt):return dt.isoformat().replace('+00:00','Z')
def path_for(grant_id):
    if not grant_id or not all(c.isalnum() or c in '_-' for c in grant_id):raise ValueError('invalid grant ID')
    return os.path.join(os.environ['MEDUSA_GRANTS_DIR'],grant_id+'.grant.json')
def load_trusted():
    with open(os.environ['MEDUSA_TRUSTED_SIGNERS']) as f:return json.load(f)
def _private(p):
    with open(p,'rb') as f:return serialization.load_pem_private_key(f.read(),password=None)
def _pub(k):return base64.b64encode(k.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode()
def _valid_signer(decider,pub_b64, trusted):
    return any(x.get('decider')==decider and x.get('public_key_b64')==pub_b64 for x in trusted.get('signers',[]))
def verify_grant(g,trusted=None):
    try:
        trusted=trusted or load_trusted()
        if g.get('revoked_at'): return False,'revoked'
        pub=next((x.get('public_key_b64') for x in trusted.get('signers',[]) if x.get('decider')==g.get('decider')),None)
        if not pub:return False,'unknown signer'
        payload={k:v for k,v in g.items() if k not in ('signature','revoked_at','revocation_signature')}
        Ed25519PublicKey.from_public_bytes(base64.b64decode(pub)).verify(bytes.fromhex(g['signature']),canon(payload))
        if datetime.fromisoformat(g['expires_at'].replace('Z','+00:00'))<=now():return False,'expired'
        if g.get('action_class') not in ACTION_CLASSES:return False,'unsupported class'
        if not os.path.isabs(g.get('target_scope','')):return False,'invalid scope'
        if g.get('max_blast_radius',0)<1:return False,'invalid blast radius'
        return True,'valid'
    except Exception as exc:return False,f'invalid signature or grant: {type(exc).__name__}'
def issue(a):
    import eventbus
    eventbus.lab_only()
    key=_private(a.key); trusted=load_trusted()
    if not _valid_signer(a.decider,_pub(key),trusted):raise ValueError('decider key not trusted')
    if a.action_class not in ACTION_CLASSES: raise ValueError('unsupported action class')
    p=path_for(a.grant_id)
    payload={'grant_id':a.grant_id,'decider':a.decider,'action_class':a.action_class,
        'target_scope':os.path.realpath(a.target_scope),'excluded_paths':[],
        'max_blast_radius':a.blast_radius,'requires_evidence_tag':a.evidence,
        'requires_detection_severity':a.severity,
        'issued_at':timestamp(now()),'expires_at':timestamp(now()+timedelta(hours=a.hours))}
    record={**payload,'signature':key.sign(canon(payload)).hex()}
    os.makedirs(os.path.dirname(p),exist_ok=True)
    flags=os.O_CREAT|os.O_EXCL|os.O_WRONLY
    if hasattr(os,'O_NOFOLLOW'):flags|=os.O_NOFOLLOW
    with os.fdopen(os.open(p,flags,0o600),'w') as f:
        json.dump(record,f);f.flush();os.fsync(f.fileno())
    print(f'ISSUED: {a.grant_id}')
def revoke(a):
    import eventbus
    eventbus.lab_only()
    p=path_for(a.grant_id)
    with open(p) as f: g=json.load(f)
    if g.get('decider')!=a.decider: raise ValueError('decider mismatch')
    key=_private(a.key)
    if not _valid_signer(a.decider,_pub(key),load_trusted()):raise ValueError('decider key not trusted')
    ok,reason=verify_grant(g)
    if not ok:raise ValueError(reason)
    g['revoked_at']=timestamp(now())
    g['revocation_signature']=key.sign(canon({'grant_id':a.grant_id,'revoked_at':g['revoked_at']})).hex()
    tmp=p+'.'+uuid.uuid4().hex+'.tmp'
    with open(tmp,'x') as f:json.dump(g,f);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
    print(f'REVOKED: {a.grant_id}')
def main():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    s=sub.add_parser('issue');s.add_argument('--decider',required=True);s.add_argument('--key',required=True)
    s.add_argument('--action-class',required=True);s.add_argument('--target-scope',required=True)
    s.add_argument('--blast-radius',type=int,default=1);s.add_argument('--evidence',required=True)
    s.add_argument('--severity',required=True);s.add_argument('--hours',type=float,default=1);s.add_argument('--grant-id',required=True)
    s=sub.add_parser('revoke');s.add_argument('grant_id');s.add_argument('--decider',required=True);s.add_argument('--key',required=True)
    s=sub.add_parser('verify');s.add_argument('grant_id')
    a=p.parse_args()
    try:
        if a.cmd=='issue':issue(a)
        elif a.cmd=='revoke':revoke(a)
        else:
            with open(path_for(a.grant_id)) as f:g=json.load(f)
            ok,reason=verify_grant(g);print(('VERIFY: PASS ' if ok else 'VERIFY: FAIL ')+reason);sys.exit(0 if ok else 1)
    except Exception as exc:print(f'grant: {type(exc).__name__}: {exc}',file=sys.stderr);sys.exit(1)
if __name__=='__main__':main()
