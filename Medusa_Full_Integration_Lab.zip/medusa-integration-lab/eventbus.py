#!/usr/bin/env python3
"""LAB-ONLY Medusa-compatible signed event bus. No production certification."""
from __future__ import annotations
import argparse, base64, fcntl, hashlib, json, os, sys, uuid
from datetime import datetime, timezone
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

EVENT_TYPES = (
    'sensor_heartbeat', 'sensor_error', 'fs_change', 'process_start', 'process_exit',
    'net_connect', 'ci_start', 'ci_step', 'ci_end', 'config_change', 'code_change',
    'detection_feedback', 'correction', 'action_request', 'action_result',
    'pipeline_run', 'policy_unmatched',
)

def lab_only():
    if os.environ.get('MEDUSA_LAB_MODE') != '1':
        raise RuntimeError('LAB-ONLY module: MEDUSA_LAB_MODE=1 required; not production-authorized')

def bus_dir(): return os.environ['MEDUSA_BUS_DIR']
def log_path(): return os.path.join(bus_dir(), 'events.jsonl')
def sensor_trust_path(): return os.environ['MEDUSA_TRUSTED_SENSORS']
def anchor_trust_path(): return os.environ['MEDUSA_TRUSTED_ANCHORS']
def canon(obj): return json.dumps(obj, sort_keys=True, separators=(',', ':')).encode('utf-8')
def now(): return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def sha(data): return hashlib.sha256(data).hexdigest()

def _priv(path):
    with open(path,'rb') as f: k=serialization.load_pem_private_key(f.read(),password=None)
    return k

def _pub(k):
    return base64.b64encode(k.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode()

def _load(path, key):
    if not os.path.isfile(path): return {key: []}
    with open(path, encoding='utf-8') as f: return json.load(f)

def _write(path, obj):
    os.makedirs(os.path.dirname(path),exist_ok=True)
    tmp=path+'.'+uuid.uuid4().hex+'.tmp'
    fd=os.open(tmp, os.O_CREAT|os.O_EXCL|os.O_WRONLY, 0o600)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(canon(obj)); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def _trust(kind):
    path = sensor_trust_path() if kind=='sensors' else anchor_trust_path()
    obj=_load(path,kind)
    return {r.get('sensor_id' if kind=='sensors' else 'anchor_id'):r['public_key_b64'] for r in obj[kind]}

def register(sensor_id, key_path, *, kind='sensors'):
    lab_only()
    k=_priv(key_path); pub=_pub(k)
    path=sensor_trust_path() if kind=='sensors' else anchor_trust_path()
    name='sensor_id' if kind=='sensors' else 'anchor_id'
    os.makedirs(os.path.dirname(path),exist_ok=True)
    with open(path+'.lock','a+b') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        doc=_load(path,kind)
        existing=next((r for r in doc[kind] if r[name]==sensor_id),None)
        if existing and existing['public_key_b64']!=pub:
            raise ValueError('identity exists with a different public key')
        if not existing:
            doc[kind].append({name:sensor_id,'public_key_b64':pub})
            _write(path,doc)

def _locked_records():
    if not os.path.exists(log_path()): return []
    with open(log_path(),'r',encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]

def _check(records):
    trusted=_trust('sensors'); prev=''; ids=set()
    for n,rec in enumerate(records):
        e=rec['event']; payload=rec['payload']
        if e['seq']!=n: raise ValueError(f'broken sequence at {n}')
        if e['prev_event_hash']!=prev: raise ValueError(f'broken chain at {n}')
        if e['event_id'] in ids: raise ValueError(f'duplicate event id at {n}')
        ids.add(e['event_id'])
        signed={k:v for k,v in e.items() if k not in ('signature','event_hash')}
        digest=sha(canon({'event':signed,'payload':payload}))
        if digest!=e['event_hash']: raise ValueError(f'event hash mismatch at {n}')
        pub=trusted.get(e['sensor_id'])
        if not pub: raise ValueError(f'untrusted event signer at {n}')
        Ed25519PublicKey.from_public_bytes(base64.b64decode(pub)).verify(
            bytes.fromhex(e['signature']), bytes.fromhex(digest))
        prev=digest
    return prev

def read_events():
    lab_only()
    os.makedirs(bus_dir(),exist_ok=True)
    with open(os.path.join(bus_dir(),'.lock'),'a+b') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_SH)
        records=_locked_records()
        _check(records)
    return records

def append_event(sensor_id, event_type, payload, key_path, allow_self_registration=False):
    lab_only()
    if event_type not in EVENT_TYPES: raise ValueError('event type not in schema')
    if not isinstance(payload, dict): raise ValueError('payload must be a JSON object')
    k=_priv(key_path)
    registered=_trust('sensors')
    if sensor_id not in registered or registered[sensor_id]!=_pub(k):
        # Never grant signing authority as a side effect of append_event.
        # Enrollment must be an explicit trust-store management action.
        raise ValueError('untrusted sensor identity (explicit registration required)')
    os.makedirs(bus_dir(),exist_ok=True)
    with open(os.path.join(bus_dir(),'.lock'),'a+b') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        entries=_locked_records()
        prev=_check(entries)
        e={'event_id':uuid.uuid4().hex,'event_type':event_type,'sensor_id':sensor_id,
           'observed_at':now(),'seq':len(entries),'prev_event_hash':prev}
        digest=sha(canon({'event':e,'payload':payload}))
        e['event_hash']=digest; e['signature']=k.sign(bytes.fromhex(digest)).hex()
        rec={'event':e,'payload':payload}
        with open(log_path(),'a',encoding='utf-8') as f:
            f.write(json.dumps(rec,separators=(',',':'))+'\n'); f.flush(); os.fsync(f.fileno())
        return rec

def checkpoint(anchor_id,key_path):
    lab_only()
    k=_priv(key_path)
    if _trust('anchors').get(anchor_id)!=_pub(k): raise ValueError('anchor not registered in external trust')
    entries=read_events()
    if not entries: raise ValueError('cannot anchor empty bus')
    payload={'anchor_id':anchor_id,'chain_length':len(entries),'last_event_hash':entries[-1]['event']['event_hash'],'at':now()}
    signed={**payload,'signature':k.sign(canon(payload)).hex()}
    directory=os.path.join(os.path.dirname(bus_dir()),'anchors')
    _write(os.path.join(directory,anchor_id+'.checkpoint.json'),signed)
    return signed

def verify_chain(strict=False,anchor=None):
    lab_only()
    try:
        records=read_events()
        if strict:
            if not anchor: return {'ok':False,'reason':'strict verification requires anchor'}
            path=os.path.join(os.path.dirname(bus_dir()),'anchors',anchor+'.checkpoint.json')
            with open(path,encoding='utf-8') as f: signed=json.load(f)
            pub=_trust('anchors').get(anchor)
            if not pub: return {'ok':False,'reason':'untrusted checkpoint anchor'}
            payload={k:v for k,v in signed.items() if k!='signature'}
            Ed25519PublicKey.from_public_bytes(base64.b64decode(pub)).verify(
                bytes.fromhex(signed['signature']),canon(payload))
            if len(records)<signed['chain_length']:
                return {'ok':False,'reason':f'truncated: {len(records)} < {signed["chain_length"]}'}
            if records[signed['chain_length']-1]['event']['event_hash']!=signed['last_event_hash']:
                return {'ok':False,'reason':'checkpoint diverged'}
        return {'ok':True,'reason':'chain intact','entries':len(records)}
    except Exception as exc:
        return {'ok':False,'reason':f'{type(exc).__name__}: {exc}'}

def main():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    s=sub.add_parser('register'); s.add_argument('--sensor-id',required=True);s.add_argument('--key',required=True)
    s=sub.add_parser('register-anchor');s.add_argument('--anchor-id',required=True);s.add_argument('--key',required=True)
    s=sub.add_parser('checkpoint');s.add_argument('--anchor-id',required=True);s.add_argument('--key',required=True)
    s=sub.add_parser('verify');s.add_argument('--strict',action='store_true');s.add_argument('--anchor')
    s=sub.add_parser('tail');s.add_argument('-n',type=int,default=20)
    a=p.parse_args()
    try:
        if a.cmd=='register':register(a.sensor_id,a.key)
        if a.cmd=='register-anchor':register(a.anchor_id,a.key,kind='anchors')
        if a.cmd=='checkpoint': print(json.dumps(checkpoint(a.anchor_id,a.key)))
        if a.cmd=='tail':
            for rec in read_events()[-a.n:]:print(json.dumps(rec))
        if a.cmd=='verify':
            r=verify_chain(a.strict,a.anchor);print(('VERIFY: OK' if r['ok'] else 'VERIFY: FAIL')+' — '+r['reason']);sys.exit(0 if r['ok'] else 1)
    except Exception as exc:
        print(f'eventbus: {type(exc).__name__}: {exc}',file=sys.stderr);sys.exit(1)
if __name__=='__main__':main()
