# Medusa Layer 6 v3 — local integration candidate

**Not installed. Not deployed. Not authoritative.** This package is an independently authored local reconstruction of the supplied Layer 6 v3 design, with additional fail-closed corrections. It is **not** identical to the chat's pasted implementation and has not been compared with any GitHub branch.

## Contents

- `medusa_daemon.py`: a local supervisor compatible in design with the proposed Medusa bus/detect/actuator/grant APIs. No network fetches or shell commands inside the supervisor.
- `composition.example.json`: production-shaped declarative example; not a deployable configuration.
- `acceptance.sh`: synthetic end-to-end check, **blocked** unless required Layer 1–5 modules are supplied in the same directory. Does not delete test artifacts.
- `tests/test_layer6_contract.py`: isolated regression tests, using synthetic fixtures / test doubles at external module boundaries.
- `TEST_RECEIPT.txt`, `SHA256SUMS.txt`, `red-test.log`, `green-test.log`, `acceptance-attempt.log`.

## Run local focused checks

```bash
python3 -m pytest -q tests/test_layer6_contract.py
python3 -m py_compile medusa_daemon.py
bash -n acceptance.sh
```

## E2E dependencies (not included)

`eventbus.py`, `detect.py`, `actuator.py`, `authority_grant.py`, and `fs_sensor.py`, plus `watchdog`, `pyyaml`, and `cryptography`. The real modules' exact event schemas, CLI contracts, and outcome strings are **unverified**. The runner stops before any synthetic setup when files are absent.

The only accepted success string in this local supervisor is `outcome=quarantined`; any unknown outcome is escalated, not treated as a successful action. Confirm the actual Layer 4 outcome contract before integration.

**Outstanding security limitations:** The supervisor has not achieved crash-atomic exactly-once action dispatch. Bus append and cursor persistence are two distinct operations; a crash between an irreversible action and cursor save may replay an action. The bus-based detection dedup specifically reduces *duplicate detections*, not this action-retry risk. An idempotency key / durable action claim and an actuator-enforced duplicate-action refusal are prerequisites for strong exactly-once semantics. External key custody, anchor independence, and deploy-side digest enforcement remain outside this implementation.

## Trust/authority boundaries

The package has no keys, credentials, or private user content. No connected account, public site, repository, DNS, or deployment was modified.
