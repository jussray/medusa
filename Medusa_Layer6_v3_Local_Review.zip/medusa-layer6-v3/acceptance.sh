#!/usr/bin/env bash
# Medusa Layer 6 synthetic acceptance. Requires REAL Layers 1–5; never mocks them.
# Lab target under a fresh /tmp directory. Never modifies real services.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PASS=0; FAIL=0; FAILS=(); DAEMON_PID=""; ROOT=""
pass() { printf 'PASS: %s\n' "$1"; PASS=$((PASS+1)); }
fail() { printf 'FAIL: %s\n' "$1"; FAIL=$((FAIL+1)); FAILS+=("$1"); }
cleanup() {
  if [[ -n "$DAEMON_PID" ]] && kill -0 "$DAEMON_PID" 2>/dev/null; then
    kill -TERM "$DAEMON_PID" 2>/dev/null || true
    wait "$DAEMON_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT
for file in eventbus.py detect.py actuator.py authority_grant.py fs_sensor.py medusa_daemon.py; do
  if [[ ! -f "$HERE/$file" ]]; then
    printf 'BLOCKED: Missing required Layer 1–5 module: %s (no E2E tests ran)\n' "$file" >&2
    exit 2
  fi
done
for bin in openssl python3; do
  command -v "$bin" >/dev/null 2>&1 || { printf 'BLOCKED: %s required\n' "$bin" >&2; exit 2; }
done
python3 - <<'PY'
import yaml, watchdog, cryptography
PY
if [[ $? -ne 0 ]]; then printf 'BLOCKED: install yaml/watchdog/cryptography\n' >&2; exit 2; fi
ROOT="$(mktemp -d /tmp/medusa-l6-accept.XXXXXXXX)"
export PYTHONPATH="$HERE${PYTHONPATH:+:$PYTHONPATH}"
export MEDUSA_BUS_DIR="$ROOT/bus"
export MEDUSA_TRUSTED_SENSORS="$ROOT/trusted_sensors.json"
export MEDUSA_TRUSTED_SIGNERS="$ROOT/trusted_signers.json"
export MEDUSA_TRUSTED_ANCHORS="$ROOT/trusted_anchors.json"
export MEDUSA_GRANTS_DIR="$ROOT/grants"
export MEDUSA_QUARANTINE_DIR="$ROOT/quarantine"
export MEDUSA_UNDO_DIR="$ROOT/undo"
export MEDUSA_DETECT_DIR="$ROOT/detect"
export MEDUSA_ACTUATOR_DIR="$ROOT/state"
mkdir -p "$MEDUSA_BUS_DIR" "$MEDUSA_GRANTS_DIR" "$MEDUSA_QUARANTINE_DIR" "$MEDUSA_UNDO_DIR" \
  "$MEDUSA_DETECT_DIR" "$MEDUSA_ACTUATOR_DIR" "$ROOT/keys" "$ROOT/rules" "$ROOT/sensors" \
  "$ROOT/watch" "$ROOT/outside" "$ROOT/state"
for key in alice anchor fs-sensor detect-1 actuator-1; do
  openssl genpkey -algorithm ED25519 -out "$ROOT/keys/$key.pem" 2>/dev/null || exit 2
done
printf '{"signers":[]}\n' > "$MEDUSA_TRUSTED_SIGNERS"
printf '{"sensors":[]}\n' > "$MEDUSA_TRUSTED_SENSORS"
printf '{"anchors":[]}\n' > "$MEDUSA_TRUSTED_ANCHORS"
python3 - "$MEDUSA_TRUSTED_SIGNERS" "$ROOT/keys/alice.pem" <<'PY'
import sys,json,base64
from cryptography.hazmat.primitives import serialization
with open(sys.argv[2],'rb') as f: key=serialization.load_pem_private_key(f.read(),password=None)
pub=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
with open(sys.argv[1],'w') as f:
    json.dump({'signers':[{'decider':'alice','public_key_b64':base64.b64encode(pub).decode()}]},f)
PY
for sid in fs-sensor detect-1 actuator-1; do
  python3 "$HERE/eventbus.py" register --sensor-id "$sid" --key "$ROOT/keys/$sid.pem" > "$ROOT/register-$sid.log" 2>&1 || {
    printf 'BLOCKED: eventbus register failed for %s\n' "$sid" >&2; exit 2;
  }
done
pass "Synthetic sensor keys registered"
cat > "$ROOT/sensors/fs.json" <<JSON
{"sensor_id":"fs-sensor","key_path":"$ROOT/keys/fs-sensor.pem",
"watch":[{"path":"$ROOT/watch","recursive":true}],
"events":["fs_change"],"coalesce_ms":100,"max_events_per_sec":100}
JSON
cat > "$ROOT/rules/fs.yml" <<'YAML'
ruleset_id: fs-v1
version: "1"
lookback_s: 300
rules:
  - id: fs-001-sensitive-file-write
    description: Synthetic .env write
    severity: High
    confidence: medium
    evidence_tag: VERIFIED
    when:
      all:
        - event_type: fs_change
        - where: {action: write}
        - path_matches: '(^|/)\.env$'
YAML
python3 - "$ROOT" <<'PY'
import json,sys,os
r=sys.argv[1]
e=os.environ
cfg={"bus_dir":e['MEDUSA_BUS_DIR'],"trusted_sensors":e['MEDUSA_TRUSTED_SENSORS'],
"trusted_signers":e['MEDUSA_TRUSTED_SIGNERS'],"trusted_anchors":e['MEDUSA_TRUSTED_ANCHORS'],
"grants_dir":e['MEDUSA_GRANTS_DIR'],"quarantine_dir":e['MEDUSA_QUARANTINE_DIR'],
"undo_dir":e['MEDUSA_UNDO_DIR'],"detect_dir":e['MEDUSA_DETECT_DIR'],
"state_dir":r+'/state',"detect_sensor_id":"detect-1","detect_key":r+'/keys/detect-1.pem',
"sensors":[{"name":"fs-app","module":"fs_sensor","config":r+'/sensors/fs.json'}],
"rulesets":[r+'/rules/fs.yml'],"actuator":{"sensor_id":"actuator-1","key_path":r+'/keys/actuator-1.pem'},
"detect_interval_s":2,"action_policy":[{"match":{"rule_id":"fs-001-sensitive-file-write","min_severity":"High"},"action_class":"quarantine_file","target_field":"path"},
{"match":{"min_severity":"Critical"},"action_class":"escalate_only"}]}
with open(r+'/composition.json','w') as f: json.dump(cfg,f,indent=2)
PY
OUT="$(python3 "$HERE/medusa_daemon.py" preflight --config "$ROOT/composition.json" 2>&1)"; RC=$?
if [[ "$RC" -eq 0 && "$OUT" == *"no active grants"* ]]; then
  pass "Preflight allows escalation-only operation without grants"
else fail "No-grant preflight (exit $RC): $OUT"; fi
python3 "$HERE/medusa_daemon.py" run --config "$ROOT/composition.json" > "$ROOT/daemon.log" 2>&1 &
DAEMON_PID=$!
sleep 3
if kill -0 "$DAEMON_PID" 2>/dev/null; then pass "Primary daemon started"; else fail "Primary daemon failed"; fi
OUT="$(python3 "$HERE/medusa_daemon.py" run --config "$ROOT/composition.json" 2>&1)"; RC=$?
if [[ "$RC" -ne 0 && "$OUT" == *"another daemon holds"* ]]; then pass "Duplicate daemon refused"; else fail "Duplicate daemon not refused (exit $RC)"; fi
bus_count() {
  python3 - "$1" <<'PY'
import eventbus,sys
kind=sys.argv[1]
print(sum(1 for r in eventbus.read_events() if r['event']['event_type']==kind))
PY
}
BEFORE="$(bus_count detection_feedback)"
printf 'synthetic_key=value_a\n' > "$ROOT/watch/.env"
sleep 12
MID="$(bus_count detection_feedback)"
if [[ "$((MID-BEFORE))" -eq 1 ]]; then pass "One unique detection (no replay over six cycles)"; else fail "Expected one detection, got $((MID-BEFORE))"; fi
if [[ -f "$ROOT/watch/.env" ]]; then pass "No grant: target remained intact"; else fail "No grant: unauthorized action"; fi
if [[ "$(bus_count action_request)" -ge 1 ]]; then pass "Escalation emitted without grant"; else fail "No escalation event"; fi
python3 "$HERE/authority_grant.py" issue --decider alice --key "$ROOT/keys/alice.pem" \
 --action-class quarantine_file --target-scope "$ROOT/watch" --blast-radius 1 \
 --evidence VERIFIED --severity High --hours 1 --grant-id g-accept > "$ROOT/issue.log" 2>&1
if [[ $? -ne 0 ]]; then fail "Grant issuance failed"; else pass "Synthetic grant issued"; fi
printf 'synthetic_key=value_b\n' > "$ROOT/watch/.env"
sleep 12
QUARANTINED="$(find "$MEDUSA_QUARANTINE_DIR" -type f -name '.env' -print -quit 2>/dev/null)"
if [[ -n "$QUARANTINED" && ! -f "$ROOT/watch/.env" ]]; then pass "Authorized quarantine occurred"; else fail "Authorized quarantine missing"; fi
UNDO_ID="$(find "$MEDUSA_UNDO_DIR" -maxdepth 1 -type f -name '*.undo.json' -printf '%f\n' | head -1 | sed 's/\.undo\.json$//')"
if [[ -n "$UNDO_ID" ]]; then
  python3 "$HERE/actuator.py" undo --actuator-id actuator-1 --key "$ROOT/keys/actuator-1.pem" "$UNDO_ID" > "$ROOT/undo.log" 2>&1
  if [[ $? -eq 0 && -f "$ROOT/watch/.env" ]]; then pass "Undo restored target"; else fail "Undo unsuccessful"; fi
else fail "Undo token absent"; fi
printf 'synthetic_key=out_of_scope\n' > "$ROOT/outside/.env"
DET_ID="$(python3 - <<'PY'
import eventbus
ids=[r['event']['event_id'] for r in eventbus.read_events() if r['event']['event_type']=='detection_feedback']
print(ids[-1] if ids else '')
PY
)"
if [[ -n "$DET_ID" ]]; then
  python3 "$HERE/actuator.py" execute --actuator-id actuator-1 --key "$ROOT/keys/actuator-1.pem" \
    --detection-event "$DET_ID" --grant g-accept --target "$ROOT/outside/.env" > "$ROOT/outside.log" 2>&1
  RC=$?
  if [[ "$RC" -ne 0 && -f "$ROOT/outside/.env" ]]; then pass "Out-of-scope target refused"; else fail "Out-of-scope test failed"; fi
else fail "No detection event for out-of-scope test"; fi
python3 "$HERE/authority_grant.py" revoke g-accept --decider alice --key "$ROOT/keys/alice.pem" > "$ROOT/revoke.log" 2>&1
if [[ $? -ne 0 ]]; then fail "Grant revocation failed"; fi
python3 "$HERE/authority_grant.py" verify g-accept > "$ROOT/verify-revoked.log" 2>&1
RC=$?
if [[ "$RC" -ne 0 ]]; then pass "Revoked grant verification refused"; else fail "Revoked grant still valid"; fi
python3 "$HERE/actuator.py" execute --actuator-id actuator-1 --key "$ROOT/keys/actuator-1.pem" \
 --detection-event "$DET_ID" --grant g-accept --target "$ROOT/watch/.env" > "$ROOT/revoked-action.log" 2>&1
RC=$?
if [[ "$RC" -ne 0 ]]; then pass "Revoked grant execution refused"; else fail "Revoked grant action allowed"; fi
REQUESTS_BEFORE="$(bus_count action_request)"
printf 'synthetic_key=value_c\n' > "$ROOT/watch/.env"
sleep 12
REQUESTS_AFTER="$(bus_count action_request)"
if [[ "$REQUESTS_AFTER" -gt "$REQUESTS_BEFORE" && -f "$ROOT/watch/.env" ]]; then
  pass "Post-revoke escalation, no quarantine"
else fail "Post-revoke escalation absent or unauthorized action"; fi
python3 - <<'PY'
import medusa_daemon as D
p=[{'match':{'rule_id':'fs-001','min_severity':'High'},'action_class':'quarantine_file','target_field':'path'},
   {'match':{'min_severity':'Critical'},'action_class':'escalate_only'}]
assert D.apply_policy({'payload':{'rule_id':'fs-001','severity':'Critical'}},p)==('escalate_only',None)
assert D.apply_policy({'payload':{'rule_id':'fs-001','severity':'High'}},p)==('quarantine_file','path')
PY
if [[ $? -eq 0 ]]; then pass "Policy precedence evaluated"; else fail "Policy precedence invalid"; fi
kill -TERM "$DAEMON_PID" 2>/dev/null || true
wait "$DAEMON_PID" 2>/dev/null || true
DAEMON_PID=""
if pgrep -f "fs_sensor.py --config $ROOT/sensors/fs.json" >/dev/null 2>&1; then fail "Sensor orphaned"; else pass "Clean shutdown without orphaned sensor"; fi
python3 "$HERE/eventbus.py" checkpoint --anchor-id accept-anchor --key "$ROOT/keys/anchor.pem" > "$ROOT/checkpoint.log" 2>&1
if [[ $? -ne 0 ]]; then
  fail "Checkpoint unavailable (anchor trust/registration unverified)"
else
  head -3 "$MEDUSA_BUS_DIR/events.jsonl" > "$MEDUSA_BUS_DIR/events.trim"
  mv "$MEDUSA_BUS_DIR/events.trim" "$MEDUSA_BUS_DIR/events.jsonl"
  python3 "$HERE/eventbus.py" verify --strict --anchor accept-anchor > "$ROOT/verify-truncated.log" 2>&1
  RC=$?
  if [[ "$RC" -ne 0 ]] && grep -qi truncated "$ROOT/verify-truncated.log"; then
    pass "Truncation rejected with nonzero exit"
  else fail "Truncation test failed (exit $RC)"; fi
fi
printf '\nPASS=%d FAIL=%d\nArtifacts: %s\n' "$PASS" "$FAIL" "$ROOT"
if [[ "$FAIL" -ne 0 ]]; then
  for message in "${FAILS[@]}"; do printf ' - %s\n' "$message"; done
  exit 1
fi
printf 'ACCEPTANCE PASSED ON SYNTHETIC LAB\n'
